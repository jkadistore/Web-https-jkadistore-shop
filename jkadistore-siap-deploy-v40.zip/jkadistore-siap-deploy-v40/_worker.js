// JK ADISTORE — Worker Full Stack v4
const ORIGIN = 'https://25bd5ade.jkadistore.pages.dev';
const OWNER_HASH = '40cab8d2f729224df61b82dbc8f149d680305071a8e98d820d5c598622ebd506'; // sha256 password owner lama (ganti lewat variabel Cloudflare: OWNER_SHA256)
const OWNER_EMAIL = 'jkadistore2@gmail.com';

function json(data, status = 200, extra) {
  const h = new Headers({ 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  if (extra && extra.cookies) extra.cookies.forEach(c => h.append('Set-Cookie', c));
  return new Response(JSON.stringify(data), { status, headers: h });
}

async function sha256(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str || ''));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ====================== SESI SERVER (token HMAC + cookie HttpOnly) ======================
   Rahasia penanda tangan: env.SESSION_SECRET (disarankan diset di Cloudflare).
   Bila belum diset, diturunkan dari RESEND_API_KEY + OWNER_HASH (tetap aman, tapi set SESSION_SECRET). */
const COOKIE_NAME = 'jka_sess';
const TTL_USER = 60 * 60 * 24 * 30;   // 30 hari
const TTL_OWNER = 60 * 60 * 24;       // owner: 24 jam
const OTP_COOLDOWN = 30;              // detik antar pengiriman kode
const _enc = new TextEncoder();

function b64uEnc(bytes) { let s = ''; bytes.forEach(b => { s += String.fromCharCode(b); }); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
function b64uDec(str) { str = str.replace(/-/g, '+').replace(/_/g, '/'); while (str.length % 4) str += '='; const bin = atob(str); const out = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out; }
let _rndSecret = '';
function sessionSecret(env) {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  if (env.RESEND_API_KEY) return 'jk|' + env.RESEND_API_KEY + '|' + OWNER_HASH;
  // Tanpa rahasia di Cloudflare, jangan pakai nilai yang bisa ditebak dari kode: pakai acak per-proses (tidak bisa dipalsukan)
  if (!_rndSecret) { const r = new Uint8Array(32); crypto.getRandomValues(r); _rndSecret = Array.from(r).map(x => x.toString(16).padStart(2, '0')).join(''); }
  return _rndSecret;
}
async function hmacKey(env) { return crypto.subtle.importKey('raw', _enc.encode(sessionSecret(env)), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']); }
async function makeToken(env, p) {
  const prefix = p.r === 'owner' ? 'JK2FA_' : 'JKUSR_';
  const body = b64uEnc(_enc.encode(JSON.stringify(p)));
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', await hmacKey(env), _enc.encode(prefix + body)));
  return prefix + body + '.' + b64uEnc(sig);
}
async function readToken(env, tok) {
  try {
    const m = /^(JK2FA_|JKUSR_)([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(String(tok || ''));
    if (!m) return null;
    const ok = await crypto.subtle.verify('HMAC', await hmacKey(env), b64uDec(m[3]), _enc.encode(m[1] + m[2]));
    if (!ok) return null;
    const p = JSON.parse(new TextDecoder().decode(b64uDec(m[2])));
    if (!p || !p.e || !p.x || p.x < Math.floor(Date.now() / 1000)) return null;
    if ((m[1] === 'JK2FA_') !== (p.r === 'owner')) return null;
    return p;
  } catch (e) { return null; }
}
function readCookie(request, name) {
  const c = request.headers.get('Cookie') || '';
  const m = c.split(/;\s*/).find(x => x.indexOf(name + '=') === 0);
  if (!m) return '';
  try { return decodeURIComponent(m.slice(name.length + 1)); } catch (e) { return ''; }
}
function isHttps(request) { try { return new URL(request.url).protocol === 'https:' || request.headers.get('X-Forwarded-Proto') === 'https'; } catch (e) { return false; } }
function sessionCookie(request, token, maxAge) { return COOKIE_NAME + '=' + encodeURIComponent(token) + '; Path=/; Max-Age=' + maxAge + '; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''); }
function clearCookie(request) { return COOKIE_NAME + '=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''); }
function dbOf(env) { return env.DB_MAIN || env.DB_AI || env.DB_FOTO; }

async function loadUser(env, p) {
  const email = String(p.e).toLowerCase();
  if (email === OWNER_EMAIL) {
    if (p.r !== 'owner') return null;
    return { id: 'owner', email, name: 'Owner', role: 'owner', coins: 0, poin: 0, wa: '', avatar: '', joined: '' };
  }
  const db = dbOf(env); if (!db) return null;
  const row = await db.prepare('SELECT * FROM pengguna WHERE email = ?').bind(email).first();
  if (!row || !row.status_aktif) return null;
  if (p.r === 'owner' && row.peran !== 'owner') return null;           // peran diturunkan di DB -> sesi owner gugur
  const role = (p.r === 'owner' && row.peran === 'owner') ? 'owner' : 'user';
  return { id: row.id, email: row.email, name: row.nama || row.email, role, coins: row.saldo_koin || 0, poin: row.poin || 0, wa: row.wa || '', avatar: row.avatar || '', joined: row.tanggal_daftar || '' };
}
async function currentSession(request, env) {
  const auth = request.headers.get('Authorization') || '';
  const tok = readCookie(request, COOKIE_NAME) || (auth.indexOf('Bearer ') === 0 ? auth.slice(7) : '');
  const p = await readToken(env, tok);
  if (!p) return null;
  const user = await loadUser(env, p);
  return user ? { user, claims: p } : null;
}

/* limiter best-effort (per isolate) */
const _fails = new Map();

/* ====== Verifikasi robot (CAPTCHA) ======
   Mode 1: Cloudflare Turnstile bila env TURNSTILE_SITEKEY + TURNSTILE_SECRET diisi.
   Mode 2 (bawaan, tanpa setup): soal hitung bertanda-tangan HMAC, berlaku 5 menit, sekali pakai. */
const _capUsed = new Map();
async function capSign(env, msg) { return b64uEnc(new Uint8Array(await crypto.subtle.sign('HMAC', await hmacKey(env), _enc.encode('CAP|' + msg)))); }
async function handleCaptcha(env) {
  if (env.TURNSTILE_SITEKEY && env.TURNSTILE_SECRET) return json({ success: true, mode: 'turnstile', sitekey: env.TURNSTILE_SITEKEY });
  const r = new Uint32Array(3); crypto.getRandomValues(r);
  const a = 3 + (r[0] % 8), b = 2 + (r[1] % 8), plus = r[2] % 3 !== 0;
  const ans = plus ? a + b : a * 2 > b ? a * 2 - b : a + b, q = plus ? a + ' + ' + b : (a * 2 > b ? (a * 2) + ' - ' + b : a + ' + ' + b);
  const exp = Date.now() + 300000, nonce = b64uEnc(crypto.getRandomValues(new Uint8Array(6)));
  const body = ans + '.' + exp + '.' + nonce;
  return json({ success: true, mode: 'math', q: q + ' = ?', token: body + '.' + await capSign(env, body) });
}
async function botOk(request, env, body) {
  body = body || {};
  if (env.TURNSTILE_SITEKEY && env.TURNSTILE_SECRET) {
    const t = String(body.cf_token || '');
    if (!t) return false;
    try {
      const fd = new FormData(); fd.append('secret', env.TURNSTILE_SECRET); fd.append('response', t);
      const ip = request.headers.get('CF-Connecting-IP'); if (ip) fd.append('remoteip', ip);
      const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: fd });
      const j = await r.json(); return !!(j && j.success);
    } catch (e) { return false; }
  }
  const tok = String(body.cap_token || ''), m = /^(\d+)\.(\d+)\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(tok);
  if (!m) return false;
  const base = m[1] + '.' + m[2] + '.' + m[3];
  if ((await capSign(env, base)) !== m[4]) return false;
  if (Number(m[2]) < Date.now() || _capUsed.has(base)) return false;
  if (String(body.cap_answer == null ? '' : body.cap_answer).trim() !== m[1]) return false;
  _capUsed.set(base, Date.now()); if (_capUsed.size > 3000) _capUsed.clear();
  return true;
}
async function capPassOk(request, env, email) {
  const v = readCookie(request, 'jka_cap'), m = /^(\d+)\.([A-Za-z0-9_-]+)$/.exec(v);
  return !!(email && m && Number(m[1]) > Date.now() && (await capSign(env, 'P' + m[1] + '|' + String(email).toLowerCase())) === m[2]);
}
/* tiket kirim-ulang OTP: hanya untuk email yang SUDAH lolos verifikasi robot + sandi benar, 10 menit */
async function withCapPass(request, env, res, email) {
  try {
    const j = await res.clone().json();
    if (!(j && j.success && j.otp_required)) return res;
    const exp = Date.now() + 600000, h = new Headers(res.headers);
    h.append('Set-Cookie', 'jka_cap=' + exp + '.' + await capSign(env, 'P' + exp + '|' + String(email).toLowerCase()) + '; Path=/; Max-Age=600; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''));
    return new Response(res.body, { status: res.status, headers: h });
  } catch (e) { return res; }
}
const BOT_FAIL = () => json({ success: false, error: 'Verifikasi robot gagal. Jawab soal dengan benar lalu coba lagi.', captcha: true }, 400);
function tooMany(key, max, windowMs) { const r = _fails.get(key); return !!(r && Date.now() - r.t <= (windowMs || 600000) && r.n >= (max || 8)); }
function noteFail(key, windowMs) { const now = Date.now(), r = _fails.get(key); if (!r || now - r.t > (windowMs || 600000)) _fails.set(key, { n: 1, t: now }); else r.n++; if (_fails.size > 5000) _fails.clear(); }
function clientIp(request) { return request.headers.get('CF-Connecting-IP') || ''; }

/* ====== Keamanan tambahan: perbandingan aman, HMAC, hash sandi PBKDF2, pembatas persisten (D1) ====== */
function safeEq(a, b) {
  a = String(a == null ? '' : a); b = String(b == null ? '' : b);
  let d = a.length ^ b.length;
  const n = Math.max(a.length, b.length);
  for (let i = 0; i < n; i++) d |= (a.charCodeAt(i % (a.length || 1)) ^ b.charCodeAt(i % (b.length || 1)));
  return d === 0;
}
async function hmacHex(env, msg) {
  const sig = await crypto.subtle.sign('HMAC', await hmacKey(env), _enc.encode('H|' + msg));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
}
const PW_ITER_DEFAULT = 10000;   // naikkan lewat variabel PBKDF2_ITER (maks 100000) bila paket Workers berbayar
async function pbkdf2(pw, salt, iter) {
  const key = await crypto.subtle.importKey('raw', _enc.encode(String(pw)), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256));
}
async function hashPw(env, pw) {
  const iter = Math.min(100000, Math.max(10000, parseInt(env && env.PBKDF2_ITER, 10) || PW_ITER_DEFAULT));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return 'pbkdf2$' + iter + '$' + b64uEnc(salt) + '$' + b64uEnc(await pbkdf2(pw, salt, iter));
}
async function verifyPw(pw, stored) {
  stored = String(stored || '');
  if (stored.indexOf('pbkdf2$') === 0) {
    const p = stored.split('$'); if (p.length !== 4) return false;
    const iter = parseInt(p[1], 10); if (!(iter >= 1000 && iter <= 100000)) return false;
    try { return safeEq(b64uEnc(await pbkdf2(pw, b64uDec(p[2]), iter)), p[3]); } catch (e) { return false; }
  }
  return safeEq(await sha256(pw), stored);   // format lama (SHA-256 polos): masih diterima lalu di-upgrade saat login berhasil
}
const needsUpgrade = s => String(s || '').indexOf('pbkdf2$') !== 0;
let _rlReady = false;
async function ensureRl(db) {
  if (_rlReady) return;
  await db.prepare('CREATE TABLE IF NOT EXISTS ratelimit (k TEXT PRIMARY KEY, n INTEGER, t INTEGER)').run();
  _rlReady = true;
}
async function tooManyD(env, key, max, windowMs) {
  if (tooMany(key, max, windowMs)) return true;
  try {
    const db = dbOf(env); if (!db) return false; await ensureRl(db);
    const r = await db.prepare('SELECT n,t FROM ratelimit WHERE k=?').bind(key).first();
    return !!(r && Date.now() - r.t <= (windowMs || 600000) && r.n >= (max || 8));
  } catch (e) { return false; }
}
async function noteFailD(env, key, windowMs) {
  noteFail(key, windowMs);
  try {
    const db = dbOf(env); if (!db) return; await ensureRl(db);
    const now = Date.now(), win = windowMs || 600000;
    await db.prepare('INSERT INTO ratelimit (k,n,t) VALUES (?,1,?) ON CONFLICT(k) DO UPDATE SET n = CASE WHEN ? - t > ? THEN 1 ELSE n + 1 END, t = CASE WHEN ? - t > ? THEN ? ELSE t END')
      .bind(key, now, now, win, now, win, now).run();
    if (Math.random() < 0.01) await db.prepare('DELETE FROM ratelimit WHERE t < ?').bind(now - 86400000).run();
  } catch (e) {}
}
const ALLOWED_ORIGIN = /^https:\/\/([a-z0-9-]+\.)*jkadistore\.(shop|pages\.dev)$/i;
function originOk(request, url) {
  const o = request.headers.get('Origin');
  if (o && o !== 'null') { if (o === url.origin || ALLOWED_ORIGIN.test(o) || /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(o)) return true; return false; }
  if (o === 'null') return false;
  const sf = request.headers.get('Sec-Fetch-Site');
  return !sf || sf === 'same-origin' || sf === 'same-site' || sf === 'none';
}
function isPng(u) { return u[0] === 0x89 && u[1] === 0x50 && u[2] === 0x4E && u[3] === 0x47; }
function isJpg(u) { return u[0] === 0xFF && u[1] === 0xD8 && u[2] === 0xFF; }
function isWebp(u) { return u[0] === 0x52 && u[1] === 0x49 && u[2] === 0x46 && u[3] === 0x46 && u[8] === 0x57 && u[9] === 0x45 && u[10] === 0x42 && u[11] === 0x50; }
const GENERIC_ERR = 'Terjadi kesalahan. Coba lagi sebentar.';

function otp6() { const a = new Uint32Array(1); crypto.getRandomValues(a); return String(100000 + (a[0] % 900000)); }
function cleanName(s) { return String(s || '').replace(/[<>"'`&\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 40); }
async function otpWait(db, email) {
  const r = await db.prepare('SELECT created_at FROM otp_codes WHERE email = ?').bind(email).first();
  if (!r || !r.created_at) return 0;
  const left = OTP_COOLDOWN - (Math.floor(Date.now() / 1000) - r.created_at);
  return left > 0 ? left : 0;
}
async function saveOtp(db, email, code, env) {
  code = 'h:' + await hmacHex(env, 'OTP|' + email + '|' + code);
  const exp = Math.floor(Date.now() / 1000) + 300, now = Math.floor(Date.now() / 1000);
  await db.prepare('INSERT INTO otp_codes (email, code, expires, attempts, created_at) VALUES (?, ?, ?, 0, ?) ON CONFLICT(email) DO UPDATE SET code=?, expires=?, attempts=0, created_at=?').bind(email, code, exp, now, code, exp, now).run();
}
function isOwnerRoute(path, method) {
  if (path.indexOf('/api/auth/owner/') === 0) return true;
  if (path === '/api/store/save' || path === '/api/store/latest') return true;
  if (path === '/api/site-status' && method !== 'GET' && method !== 'HEAD') return true;
  return false;
}

async function sendEmail(env, to, subject, html) {
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: 'JK AdiStore <noreply@jkadistore.shop>',
      to: [to],
      subject: subject,
      html: html,
      reply_to: 'jkadistore2@gmail.com',
      headers: {
        'List-Unsubscribe': '<mailto:unsubscribe@jkadistore.shop>',
        'X-Entity-Ref-ID': Date.now().toString()
      }
    })
  });
  return r.ok;
}

function otpHtml(type, code, email) {
  var titles = {
    login: { t: 'Kode Verifikasi Login', s: 'Kami menerima permintaan login ke akun Anda. Masukkan kode di bawah untuk melanjutkan.' },
    register: { t: 'Verifikasi Akun Baru', s: 'Selamat datang di JK AdiStore! Verifikasi email Anda untuk mengaktifkan akun.' },
    reset: { t: 'Reset Kata Sandi', s: 'Kami menerima permintaan reset kata sandi. Masukkan kode di bawah untuk melanjutkan.' }
  };
  var d = titles[type] || titles.login;
  var now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' WIB';
  return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
  + '<meta name="color-scheme" content="light only"><meta name="supported-color-schemes" content="light only">'
  + '<style>body,table,td,p,h1,h2,h3,a{color-scheme:light only !important}*{forced-color-adjust:none}</style>'
  + '</head>'
  + '<body style="margin:0;padding:0;background:#f0f2f5 !important;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Arial,sans-serif">'
  + '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f0f2f5 !important;padding:32px 14px"><tr><td align="center">'
  + '<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff !important;border-radius:16px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08)">'
  + '<tr><td style="background:linear-gradient(135deg,#5b21b6 0%,#7c3aed 50%,#9333ea 100%);padding:28px 24px;text-align:center">'
  + '<h1 style="margin:0;color:#ffffff !important;font-size:22px;font-weight:900;letter-spacing:1.5px">JK ADISTORE</h1>'
  + '<p style="margin:8px 0 0;color:#c4b5fd !important;font-size:11px;letter-spacing:2.5px;text-transform:uppercase;font-weight:700">Raja Digital Store Indonesia</p>'
  + '</td></tr>'
  + '<tr><td style="padding:32px 32px 24px;text-align:center;background:#ffffff !important">'
  + '<img src="https://jkadistore.shop/assets/img/logo.png" alt="JK AdiStore" width="80" height="80" style="display:block;margin:0 auto 18px;border-radius:20px;border:0;outline:none;text-decoration:none">'
  + '<h2 style="margin:0 0 10px;color:#1f2937 !important;font-size:20px;font-weight:800">' + d.t + '</h2>'
  + '<p style="margin:0 0 28px;color:#6b7280 !important;font-size:14px;line-height:1.6">' + d.s + '</p>'
  + '<div style="background:#faf5ff;border:2px solid #a855f7;border-radius:14px;padding:20px;margin-bottom:12px;user-select:all;-webkit-user-select:all">'
  + '<p style="margin:0 0 6px;color:#7c3aed !important;font-size:11px;font-weight:800;letter-spacing:2px;text-transform:uppercase">Kode Anda</p>'
  + '<p style="margin:0;font-size:40px;font-weight:900;letter-spacing:10px;color:#1f2937 !important;font-family:Courier,monospace;line-height:1.2;user-select:all;-webkit-user-select:all">' + code + '</p>'
  + '</div>'
  + '<p style="margin:0 0 16px;color:#9ca3af !important;font-size:11px;font-style:italic">Tahan lama kotak di atas untuk menyalin kode</p>'
  + '<p style="margin:0;color:#9ca3af !important;font-size:12px">Kode berlaku selama <b style="color:#7c3aed !important">5 menit</b></p>'
  + '</td></tr>'
  + '<tr><td style="padding:0 32px 24px;background:#ffffff !important">'
  + '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb !important;border-radius:10px;border:1px solid #e5e7eb">'
  + '<tr><td style="padding:12px 16px 6px;font-size:12px;color:#6b7280 !important">Email</td><td style="padding:12px 16px 6px;font-size:12px;color:#111827 !important;text-align:right;font-weight:600">' + email + '</td></tr>'
  + '<tr><td style="padding:6px 16px;font-size:12px;color:#6b7280 !important">Waktu</td><td style="padding:6px 16px;font-size:12px;color:#111827 !important;text-align:right;font-weight:600">' + now + '</td></tr>'
  + '<tr><td style="padding:6px 16px 12px;font-size:12px;color:#6b7280 !important">Website</td><td style="padding:6px 16px 12px;font-size:12px;color:#111827 !important;text-align:right;font-weight:600">jkadistore.shop</td></tr>'
  + '</table>'
  + '</td></tr>'
  + '<tr><td style="padding:0 32px 24px;background:#ffffff !important">'
  + '<div style="background:#fef3c7 !important;border-left:4px solid #f59e0b;border-radius:6px;padding:14px 16px">'
  + '<p style="margin:0 0 8px;color:#92400e !important;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.5px">Tips Keamanan</p>'
  + '<ul style="margin:0;padding-left:20px;color:#78350f !important;font-size:12px;line-height:1.7">'
  + '<li>Jangan bagikan kode ini ke siapa pun</li>'
  + '<li>JK AdiStore tidak pernah meminta kode via telepon atau chat</li>'
  + '<li>Jika bukan Anda yang meminta, abaikan email ini</li>'
  + '</ul></div>'
  + '</td></tr>'
  + '<tr><td style="padding:0 32px 32px;text-align:center;background:#ffffff !important">'
  + '<p style="margin:0 0 12px;color:#6b7280 !important;font-size:13px">Butuh bantuan? Hubungi Customer Service kami:</p>'
  + '<a href="https://wa.me/628991232005" style="display:inline-block;padding:12px 28px;background:linear-gradient(135deg,#22c55e,#16a34a);color:#ffffff !important;text-decoration:none;border-radius:10px;font-weight:800;font-size:13px">Chat via WhatsApp</a>'
  + '</td></tr>'
  + '<tr><td style="padding:24px 32px;background:#f9fafb !important;border-top:1px solid #e5e7eb">'
  + '<p style="margin:0 0 18px;text-align:center;color:#111827 !important;font-size:13px;font-weight:800;letter-spacing:1px">IKUTI KAMI</p>'
  + '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">'
  + '<a href="https://wa.me/628991232005" style="display:inline-block;margin:5px;padding:10px 16px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827 !important;font-size:12px;font-weight:700;vertical-align:middle"><img src="https://www.google.com/s2/favicons?sz=64&domain=whatsapp.com" width="18" height="18" style="vertical-align:middle;margin-right:6px;border:0" alt="WA">WhatsApp</a>'
  + '<a href="https://t.me/jkadistore" style="display:inline-block;margin:5px;padding:10px 16px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827 !important;font-size:12px;font-weight:700;vertical-align:middle"><img src="https://www.google.com/s2/favicons?sz=64&domain=telegram.org" width="18" height="18" style="vertical-align:middle;margin-right:6px;border:0" alt="TG">Telegram</a>'
  + '<a href="https://whatsapp.com/channel/0029VbDc20N84Om3Wn4Io10L" style="display:inline-block;margin:5px;padding:10px 16px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827 !important;font-size:12px;font-weight:700;vertical-align:middle"><img src="https://www.google.com/s2/favicons?sz=64&domain=whatsapp.com" width="18" height="18" style="vertical-align:middle;margin-right:6px;border:0" alt="CH">Channel</a>'
  + '<a href="https://youtube.com/@adistoreOffc" style="display:inline-block;margin:5px;padding:10px 16px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827 !important;font-size:12px;font-weight:700;vertical-align:middle"><img src="https://www.google.com/s2/favicons?sz=64&domain=youtube.com" width="18" height="18" style="vertical-align:middle;margin-right:6px;border:0" alt="YT">YouTube</a>'
  + '<a href="https://tiktok.com/@jk.adistore" style="display:inline-block;margin:5px;padding:10px 16px;background:#ffffff;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none;color:#111827 !important;font-size:12px;font-weight:700;vertical-align:middle"><img src="https://www.google.com/s2/favicons?sz=64&domain=tiktok.com" width="18" height="18" style="vertical-align:middle;margin-right:6px;border:0" alt="TT">TikTok</a>'
  + '</td></tr></table>'
  + '<div style="height:1px;background:#e5e7eb;margin:22px 0"></div>'
  + '<p style="margin:0 0 6px;text-align:center;color:#111827 !important;font-size:13px;font-weight:800;letter-spacing:1px">&#9889; JK ADI STORE &#9889;</p>'
  + '<p style="margin:0 0 14px;text-align:center;color:#6b7280 !important;font-size:11px">Pembuat &amp; Pemilik Resmi: <b style="color:#7c3aed !important">@adistoreOffc</b></p>'
  + '<p style="margin:0 0 6px;text-align:center;color:#9ca3af !important;font-size:10.5px;line-height:1.5">Email ini dikirim otomatis oleh sistem keamanan JK AdiStore.<br>Jika bukan Anda yang meminta, abaikan email ini.</p>'
  + '<p style="margin:0;text-align:center;color:#9ca3af !important;font-size:10.5px">&copy; 2026 <a href="https://jkadistore.shop" style="color:#7c3aed !important;text-decoration:none;font-weight:700">jkadistore.shop</a> &mdash; Raja Digital Store Indonesia</p>'
  + '</td></tr>'
  + '</table></td></tr></table></body></html>';
}

async function handleOtpSend(request, env) {
  try {
    const { email, password } = await request.json();
    const input = String(email || '').toLowerCase().trim();
    const db = env.DB_MAIN || env.DB_AI || env.DB_FOTO;
    if (!db) return json({ success: false, error: 'DB error' }, 500);

    const hex = await sha256(password);
    const fk = 'login:' + input, fkip = 'loginip:' + clientIp(request);
    if (await tooManyD(env, fk, 8) || await tooManyD(env, fkip, 25)) return json({ success: false, error: 'Terlalu banyak percobaan. Coba lagi beberapa menit.' }, 429);

    let unverified = false;
    if (input === OWNER_EMAIL) {
      if (!safeEq(hex, String(env.OWNER_SHA256 || OWNER_HASH).trim().toLowerCase())) { await noteFailD(env, fk); await noteFailD(env, fkip); return json({ success: false, error: 'Email atau password salah' }, 401); }
    } else {
      const row = await db.prepare('SELECT * FROM pengguna WHERE email = ?').bind(input).first();
      if (!row) { await verifyPw(String(password || ''), 'pbkdf2$10000$AAAAAAAAAAAAAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA' ); await noteFailD(env, fk); await noteFailD(env, fkip); return json({ success: false, error: 'Email atau password salah' }, 401); }
      if (!(await verifyPw(String(password || ''), row.kata_sandi))) { await noteFailD(env, fk); await noteFailD(env, fkip); return json({ success: false, error: 'Email atau password salah' }, 401); }
      if (needsUpgrade(row.kata_sandi)) { try { await db.prepare('UPDATE pengguna SET kata_sandi=? WHERE email=?').bind(await hashPw(env, password), input).run(); } catch (e) {} }
      if (!row.status_aktif) unverified = true;   // sandi benar tapi email belum diverifikasi -> kirim kode verifikasi (tidak buntu)
    }

    const wait = await otpWait(db, input);
    if (wait > 0) return json({ success: false, error: 'Tunggu ' + wait + ' detik sebelum meminta kode lagi', retry: wait }, 429);
    const code = otp6();
    await saveOtp(db, input, code, env);

    const ok = await sendEmail(env, input, (unverified ? 'Verifikasi Akun JK AdiStore: ' : 'Kode Login JK AdiStore: ') + code, otpHtml(unverified ? 'register' : 'login', code, input));
    if (!ok) return json({ success: false, error: 'Gagal kirim OTP' }, 500);

    return json({ success: true, message: 'Kode terkirim', otp_required: true, email: input, unverified: unverified });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleOtpVerify(request, env) {
  try {
    const { email, code } = await request.json();
    const input = String(email || '').toLowerCase().trim();
    const db = env.DB_MAIN || env.DB_AI || env.DB_FOTO;
    if (!db) return json({ success: false, error: 'DB error' }, 500);

    const row = await db.prepare('SELECT * FROM otp_codes WHERE email = ?').bind(input).first();
    if (!row) return json({ success: false, error: 'Kode tidak ditemukan' }, 404);
    const now = Math.floor(Date.now() / 1000);
    if (now > row.expires) { await db.prepare('DELETE FROM otp_codes WHERE email=?').bind(input).run(); return json({ success: false, error: 'Kode kadaluarsa' }, 400); }
    if (row.attempts >= 5) { await db.prepare('DELETE FROM otp_codes WHERE email=?').bind(input).run(); return json({ success: false, error: 'Terlalu banyak percobaan' }, 429); }
    const _c = String(code == null ? '' : code).trim(), _st = String(row.code);
    const _okc = _st.indexOf('h:') === 0 ? safeEq(_st, 'h:' + await hmacHex(env, 'OTP|' + input + '|' + _c)) : safeEq(_st, _c);
    if (!_okc) {
      await db.prepare('UPDATE otp_codes SET attempts=attempts+1 WHERE email=?').bind(input).run();
      return json({ success: false, error: 'Kode salah' }, 401);
    }
    await db.prepare('DELETE FROM otp_codes WHERE email=?').bind(input).run();

    let userData = { email: input, role: 'user' };
    if (input === OWNER_EMAIL) {
      userData = { id: 'owner', email: input, name: 'Owner', role: 'owner' };
    } else {
      await db.prepare('UPDATE pengguna SET status_aktif=1, terakhir_login=? WHERE email=?').bind(new Date().toISOString(), input).run();
      const u = await db.prepare('SELECT * FROM pengguna WHERE email=?').bind(input).first();
      if (u) userData = { id: u.id, email: u.email, name: u.nama, role: u.peran === 'owner' ? 'owner' : 'user', coins: u.saldo_koin || 0 };
    }
    try { await db.prepare('INSERT INTO log_login (id, pengguna, email, metode, waktu) VALUES (?, ?, ?, ?, ?)').bind('L-'+Date.now().toString(36), userData.id || '', input, 'otp', new Date().toISOString()).run(); } catch(e){}

    if (!userData.id) return json({ success: false, error: 'Akun tidak ditemukan' }, 404);
    const ttl = userData.role === 'owner' ? TTL_OWNER : TTL_USER;
    const token = await makeToken(env, { e: input, r: userData.role, i: userData.id, x: Math.floor(Date.now() / 1000) + ttl });
    const full = await loadUser(env, { e: input, r: userData.role });
    const outUser = Object.assign({}, full || userData, { ot: userData.role === 'owner' ? 'JK2FA_srv' : 'JKUSR_srv' });
    return json({ success: true, user: outUser, message: 'Verifikasi berhasil' }, 200, { cookies: [sessionCookie(request, token, ttl)] });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleRegister(request, env) {
  try {
    let { name, email, wa, password, confirm, next } = await request.json();
    name = cleanName(name);
    next = (typeof next === 'string' && /^\/(?![\/\\])/.test(next)) ? next : '/';
    const input = String(email || '').toLowerCase().trim();
    const db = env.DB_MAIN || env.DB_AI || env.DB_FOTO;
    if (!db) return json({ success: false, error: 'DB error' }, 500);

    if (!name || name.length < 2) return json({ success: false, error: 'Nama minimal 2 karakter' }, 400);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input)) return json({ success: false, error: 'Format email tidak valid' }, 400);
    if (!password || password.length < 6) return json({ success: false, error: 'Password minimal 6 karakter' }, 400);
    if (input === OWNER_EMAIL) return json({ success: false, error: 'Email tidak boleh digunakan' }, 400);
    if (confirm != null && String(confirm) !== String(password)) return json({ success: false, error: 'Konfirmasi kata sandi tidak sama' }, 400);
    let phone = '';
    if (wa) { phone = String(wa).replace(/[^0-9]/g, ''); if (phone.indexOf('0') === 0) phone = '62' + phone.slice(1); if (!/^628\d{7,12}$/.test(phone)) return json({ success: false, error: 'Nomor telepon tidak valid (contoh: 628123456789)' }, 400); }

    const hash = await hashPw(env, password);
    const existing = await db.prepare('SELECT id, status_aktif FROM pengguna WHERE email = ?').bind(input).first();

    if (existing) {
      if (existing.status_aktif) return json({ success: false, error: 'Email sudah terdaftar' }, 400);
      await db.prepare('UPDATE pengguna SET kata_sandi=?, nama=? WHERE email=?').bind(hash, name, input).run();
    } else {
      const uid = 'U-' + Date.now().toString(36) + '-' + b64uEnc(crypto.getRandomValues(new Uint8Array(6))).replace(/[^A-Za-z0-9]/g, 'x');
      await db.prepare('INSERT INTO pengguna (id, email, kata_sandi, peran, nama, saldo_koin, tanggal_daftar, status_aktif) VALUES (?, ?, ?, ?, ?, 0, ?, 0)').bind(uid, input, hash, 'user', name, new Date().toISOString()).run();
    }

    if (phone) { try { await db.prepare('UPDATE pengguna SET wa=? WHERE email=?').bind(phone, input).run(); } catch (e) { /* kolom wa belum ada: lewati */ } }
    const wait = await otpWait(db, input);
    if (wait > 0) return json({ success: false, error: 'Tunggu ' + wait + ' detik sebelum meminta kode lagi', retry: wait }, 429);
    const code = otp6();
    await saveOtp(db, input, code, env);

    const ok = await sendEmail(env, input, 'Verifikasi Akun JK AdiStore: ' + code, otpHtml('register', code, input));
    if (!ok) return json({ success: false, error: 'Gagal kirim email' }, 500);

    return json({ success: true, otp_required: true, email: input, action: 'register', next: next || '/' });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleForgot(request, env) {
  try {
    const { email } = await request.json();
    const input = String(email || '').toLowerCase().trim();
    const db = env.DB_MAIN || env.DB_AI || env.DB_FOTO;
    if (!db) return json({ success: false, error: 'DB error' }, 500);

    const user = await db.prepare('SELECT id FROM pengguna WHERE email=?').bind(input).first();
    if (!user) return json({ success: true, message: 'Kode reset terkirim' });   // jawaban sama agar email terdaftar/tidak tidak bisa ditebak

    const prev = await db.prepare('SELECT waktu_kadaluarsa FROM pemulihan_sandi WHERE email_tujuan=? AND telah_dipakai=0 ORDER BY waktu_kadaluarsa DESC LIMIT 1').bind(input).first();
    if (prev && prev.waktu_kadaluarsa - Math.floor(Date.now() / 1000) > 300 - OTP_COOLDOWN) return json({ success: false, error: 'Tunggu sebentar sebelum meminta kode lagi' }, 429);
    const code = otp6();
    const exp = Math.floor(Date.now() / 1000) + 300;
    await db.prepare('DELETE FROM pemulihan_sandi WHERE email_tujuan=?').bind(input).run();
    await db.prepare('INSERT INTO pemulihan_sandi (id, email_tujuan, kode_6digit, waktu_kadaluarsa, telah_dipakai) VALUES (?, ?, ?, ?, 0)').bind('R-'+Date.now().toString(36), input, 'h:' + await hmacHex(env, 'RST|' + input + '|' + code), exp).run();

    const ok = await sendEmail(env, input, 'Reset Sandi JK AdiStore: ' + code, otpHtml('reset', code, input));
    if (!ok) return json({ success: false, error: 'Gagal kirim email' }, 500);

    return json({ success: true, message: 'Kode reset terkirim' });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleForgotVerify(request, env) {
  try {
    const { email, code, password, next } = await request.json();
    const input = String(email || '').toLowerCase().trim();
    const db = env.DB_MAIN || env.DB_AI || env.DB_FOTO;
    if (!db) return json({ success: false, error: 'DB error' }, 500);
    if (!password || password.length < 6) return json({ success: false, error: 'Password minimal 6 karakter' }, 400);

    const row = await db.prepare('SELECT * FROM pemulihan_sandi WHERE email_tujuan=? AND telah_dipakai=0 ORDER BY waktu_kadaluarsa DESC LIMIT 1').bind(input).first();
    if (!row) return json({ success: false, error: 'Kode tidak ditemukan' }, 404);
    if (Math.floor(Date.now()/1000) > row.waktu_kadaluarsa) return json({ success: false, error: 'Kode kadaluarsa' }, 400);
    const _rc = String(code == null ? '' : code).trim(), _rs = String(row.kode_6digit);
    const _okr = _rs.indexOf('h:') === 0 ? safeEq(_rs, 'h:' + await hmacHex(env, 'RST|' + input + '|' + _rc)) : safeEq(_rs, _rc);
    if (!_okr) {
      await db.prepare('UPDATE pemulihan_sandi SET waktu_kadaluarsa = waktu_kadaluarsa - 60 WHERE id=?').bind(row.id).run();   // tiap salah memotong 60 dtk masa berlaku (maks ~5 tebakan)
      return json({ success: false, error: 'Kode salah' }, 401);
    }

    const hash = await hashPw(env, password);
    await db.prepare('UPDATE pengguna SET kata_sandi=? WHERE email=?').bind(hash, input).run();
    await db.prepare('UPDATE pemulihan_sandi SET telah_dipakai=1 WHERE id=?').bind(row.id).run();

    return json({ success: true, message: 'Sandi berhasil diganti', next: next || '/' });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleReport(request, env) {
  try {
    const { jenis, tipe, nama, wa, deskripsi, tiket } = await request.json();
    if (!jenis || !tipe || !nama || !wa || !deskripsi) return json({ success: false, error: 'Field tidak lengkap' }, 400);
    if (deskripsi.length < 20) return json({ success: false, error: 'Deskripsi min 20 karakter' }, 400);
    const esc = s => String(s || '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
    const html = '<!DOCTYPE html><html><body style="font-family:system-ui;padding:20px"><h2 style="color:#7c3aed">Pengaduan Baru</h2><p><b>Tiket:</b> ' + esc(tiket) + '</p><p><b>Jenis:</b> ' + esc(jenis) + '</p><p><b>Tipe:</b> ' + esc(tipe) + '</p><p><b>Nama:</b> ' + esc(nama) + '</p><p><b>WA:</b> ' + esc(wa) + '</p><hr><p><b>Deskripsi:</b></p><p style="white-space:pre-wrap">' + esc(deskripsi) + '</p></body></html>';
    const ok = await sendEmail(env, OWNER_EMAIL, '[PENGADUAN ' + (tiket || '') + '] ' + tipe + ' — ' + nama, html);
    if (!ok) return json({ success: false, error: 'Gagal kirim email' }, 500);
    return json({ success: true, tiket });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handleSession(request, env) {
  const s = await currentSession(request, env);
  if (!s) return null;
  return json({ success: true, user: Object.assign({}, s.user, { ot: s.user.role === 'owner' ? 'JK2FA_srv' : 'JKUSR_srv' }) });
}

async function handleLogout(request, env) {
  const cookies = [clearCookie(request)];
  const legacy = readCookie(request, 'jka_session');
  if (legacy) {
    try {
      const r = await fetch(ORIGIN + '/api/auth/logout', { method: 'GET', headers: { Cookie: 'jka_session=' + legacy }, redirect: 'manual' });
      (r.headers.getSetCookie ? r.headers.getSetCookie() : []).forEach(c => cookies.push(c));
    } catch (e) {}
  }
  return json({ success: true }, 200, { cookies });
}


/* ====== Foto profil HD (disimpan di D1, disajikan dari /api/avatar/<id>) ====== */
async function ensureAvatars(db) { await db.prepare('CREATE TABLE IF NOT EXISTS avatars (id TEXT PRIMARY KEY, email TEXT, mime TEXT, b64 TEXT, t INTEGER)').run(); }
async function avatarId(env, email) { return (await hmacHex(env, 'avatar|' + String(email).toLowerCase())).slice(0, 20); }
async function handleAvatarUpload(request, env) {
  try {
    const s = await currentSession(request, env);
    if (!s) return json({ success: false, error: 'Belum masuk' }, 401);
    if (s.user.id === 'owner') return json({ success: false, error: 'Foto owner diatur dari Panel Owner' }, 400);
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    if (await tooManyD(env, 'av:' + s.user.email, 12, 3600000)) return json({ success: false, error: 'Terlalu sering ganti foto. Coba lagi nanti.' }, 429);
    const b = await request.json().catch(() => ({}));
    const m = /^data:(image\/(?:jpeg|webp|png));base64,([A-Za-z0-9+\/=]+)$/.exec(String(b.data || ''));
    if (!m) return json({ success: false, error: 'Format foto tidak didukung (JPG/PNG/WebP).' }, 400);
    if (m[2].length > 380000) return json({ success: false, error: 'Foto terlalu besar (maks ~280 KB setelah dikompres).' }, 413);
    try {
      const head = Uint8Array.from(atob(m[2].slice(0, 24)), c => c.charCodeAt(0));
      const okMagic = (m[1] === 'image/png' && isPng(head)) || (m[1] === 'image/jpeg' && isJpg(head)) || (m[1] === 'image/webp' && isWebp(head));
      if (!okMagic) return json({ success: false, error: 'Isi file bukan foto yang valid.' }, 400);
    } catch (e) { return json({ success: false, error: 'Isi file bukan foto yang valid.' }, 400); }
    await noteFailD(env, 'av:' + s.user.email, 3600000);
    await ensureAvatars(db);
    const id = await avatarId(env, s.user.email), t = Date.now();
    await db.prepare('INSERT INTO avatars (id,email,mime,b64,t) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET mime=excluded.mime,b64=excluded.b64,t=excluded.t').bind(id, s.user.email, m[1], m[2], t).run();
    const url = '/api/avatar/' + id + '?v=' + t;
    try { await db.prepare('UPDATE pengguna SET avatar=? WHERE email=?').bind(url, s.user.email).run(); } catch (e) {}
    return json({ success: true, url });
  } catch (e) { return json({ success: false, error: 'Gagal menyimpan foto' }, 500); }
}
async function handleAvatarGet(env, id) {
  try {
    const db = dbOf(env); if (!db || !/^[a-f0-9]{20}$/.test(id)) return new Response('Not found', { status: 404 });
    await ensureAvatars(db);
    const r = await db.prepare('SELECT mime,b64 FROM avatars WHERE id=?').bind(id).first();
    if (!r) return new Response('Not found', { status: 404 });
    const bin = atob(r.b64), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Response(u8, { headers: { 'Content-Type': r.mime, 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox" } });
  } catch (e) { return new Response('Error', { status: 500 }); }
}
async function handleProfile(request, env) {
  try {
    const s = await currentSession(request, env);
    if (!s) return json({ success: false, error: 'Belum masuk' }, 401);
    if (s.user.id === 'owner') return json({ success: false, error: 'Profil owner diatur dari Panel Owner' }, 400);
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    const b = await request.json();
    const name = cleanName(b.name);
    if (name.length < 2) return json({ success: false, error: 'Nama minimal 2 karakter' }, 400);
    const wa = String(b.wa || '').replace(/[^0-9+]/g, '').slice(0, 18);
    const avatar = (typeof b.avatar === 'string' && /^https:\/\/[^\s"'<>]{4,300}$/.test(b.avatar)) ? b.avatar : null;
    try {
      await db.prepare('UPDATE pengguna SET nama=?, wa=?, avatar=COALESCE(?, avatar) WHERE email=?').bind(name, wa, avatar, s.user.email).run();
    } catch (e) {
      await db.prepare('UPDATE pengguna SET nama=? WHERE email=?').bind(name, s.user.email).run();   // skema tanpa kolom wa/avatar
    }
    return json({ success: true, user: { name, wa, avatar } });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

async function handlePassword(request, env) {
  try {
    const s = await currentSession(request, env);
    if (!s) return json({ success: false, error: 'Belum masuk' }, 401);
    if (s.user.id === 'owner') return json({ success: false, error: 'Sandi owner diubah lewat Cloudflare (variabel OWNER_SHA256)' }, 400);
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    const b = await request.json();
    const nw = String(b.new || ''), old = String(b.old || '');
    if (nw.length < 6) return json({ success: false, error: 'Sandi baru minimal 6 karakter' }, 400);
    if (b.confirm != null && String(b.confirm) !== nw) return json({ success: false, error: 'Konfirmasi sandi tidak sama' }, 400);
    const fk = 'pw:' + s.user.email;
    if (await tooManyD(env, fk, 6)) return json({ success: false, error: 'Terlalu banyak percobaan. Coba lagi nanti.' }, 429);
    const row = await db.prepare('SELECT kata_sandi FROM pengguna WHERE email=?').bind(s.user.email).first();
    if (!row || !(await verifyPw(old, row.kata_sandi))) { await noteFailD(env, fk); return json({ success: false, error: 'Sandi saat ini salah' }, 401); }
    await db.prepare('UPDATE pengguna SET kata_sandi=? WHERE email=?').bind(await hashPw(env, nw), s.user.email).run();
    return json({ success: true, message: 'Sandi diganti' }, 200, { cookies: [clearCookie(request)] });
  } catch (e) { return json({ success: false, error: GENERIC_ERR }, 500); }
}

/* ====================== PESANAN / INVOICE ====================== */
const ORDER_STATUS = ['menunggu', 'diproses', 'berhasil', 'gagal', 'dibatalkan'];
let _ordersReady = false;
async function ensureOrders(db) {
  if (_ordersReady) return;
  await db.prepare('CREATE TABLE IF NOT EXISTS pesanan (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice TEXT UNIQUE, email TEXT, wa TEXT, produk TEXT, paket TEXT, uid TEXT, zone TEXT, nick TEXT, harga INTEGER, diskon INTEGER, total INTEGER, metode TEXT, extra TEXT, status TEXT DEFAULT \'menunggu\', catatan TEXT DEFAULT \'\', dibuat INTEGER, diubah INTEGER)').run();
  _ordersReady = true;
}
function newInvoice() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = new Uint8Array(6); crypto.getRandomValues(r);
  const d = new Date(Date.now() + 7 * 3600 * 1000), p = n => String(n).padStart(2, '0');
  return 'JK' + String(d.getUTCFullYear()).slice(2) + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) + '-' + Array.from(r).map(x => A[x % A.length]).join('');
}
function maskMid(s) { s = String(s || ''); return s.length <= 4 ? s : s.slice(0, 2) + '*'.repeat(Math.max(2, s.length - 4)) + s.slice(-2); }
async function requireOwner(request, env) {
  const s = await currentSession(request, env);
  if (!s) return json({ success: false, error: 'Belum masuk' }, 401);
  if (s.user.role !== 'owner') return json({ success: false, error: 'Akses ditolak: khusus owner' }, 403);
  return null;
}

/* ===== PROMO HARIAN: kode voucher berganti tiap hari (WIB), produk diskon 30% berbeda tiap hari ===== */
const PROMO_PCT = 30, PROMO_CAP = 50000, PROMO_RATE = 15; // 15 per 1000 produk (rata-rata sekitar 11 produk per hari)
function promoDay() { return new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10); }
function promoEnds() { const d = new Date(Date.now() + 7 * 3600e3); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1) - 7 * 3600e3; }
function mix32(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b) >>> 0; h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35) >>> 0; h ^= h >>> 16;
  return h >>> 0;
}
async function promoInfo(env) {
  const day = promoDay();
  const hx = await hmacHex(env, 'promo|' + day);
  const AL = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = ''; for (let i = 0; i < 5; i++) code += AL[parseInt(hx.slice(i * 2, i * 2 + 2), 16) % AL.length];
  return { day, code: 'JKH-' + code, seed: hx.slice(10, 26), ends: promoEnds() };
}
function promoEligible(seed, id) { return mix32(seed + '|' + String(id)) % 1000 < PROMO_RATE; }
async function handlePromo(request, env, path) {
  const ip = clientIp(request) || 'x';
  if (await tooManyD(env, 'promo:' + ip, 40, 60000)) return json({ success: false, error: 'Terlalu banyak permintaan' }, 429);
  await noteFailD(env, 'promo:' + ip, 60000);
  const p = await promoInfo(env);
  if (path === '/api/promo/today' && request.method === 'GET') return json({ success: true, day: p.day, code: p.code, pct: PROMO_PCT, cap: PROMO_CAP, ends: p.ends });
  if (path === '/api/promo/picks' && request.method === 'POST') {
    let b; try { b = await request.json(); } catch (e) { return json({ success: false, error: 'Data tidak valid' }, 400); }
    const ids = Array.isArray(b.ids) ? b.ids.slice(0, 3000).map(x => String(x).slice(0, 60)) : [];
    const picks = ids.filter(id => promoEligible(p.seed, id)).slice(0, 14);
    return json({ success: true, day: p.day, code: p.code, pct: PROMO_PCT, cap: PROMO_CAP, ends: p.ends, picks });
  }
  return json({ success: false, error: 'Tidak ditemukan' }, 404);
}
async function handleOrderCreate(request, env) {
  try {
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    const ip = clientIp(request) || 'x';
    if (await tooManyD(env, 'ord:' + ip, 12, 600000)) return json({ success: false, error: 'Terlalu banyak pesanan. Coba lagi nanti.' }, 429);
    await noteFailD(env, 'ord:' + ip, 600000);
    const b = await request.json();
    const produk = String(b.produk || '').slice(0, 80), paket = String(b.paket || '').slice(0, 120);
    if (!produk || !paket) return json({ success: false, error: 'Produk/paket wajib diisi' }, 400);
    let wa = String(b.wa || '').replace(/\D/g, ''); if (wa.startsWith('0')) wa = '62' + wa.slice(1);
    if (!/^62\d{8,13}$/.test(wa)) return json({ success: false, error: 'Nomor WhatsApp tidak valid' }, 400);
    let total = Math.round(Number(b.total)), harga = Math.round(Number(b.harga) || total), diskon = Math.round(Number(b.diskon) || 0);
    let catatan = '';
    const vch = String(b.voucher || '').trim().toUpperCase();
    if (/^JKH-/.test(vch)) {
      const pr = await promoInfo(env);
      if (vch === pr.code && b.pid && promoEligible(pr.seed, b.pid) && harga > 0) {
        diskon = Math.min(Math.round(harga * PROMO_PCT / 100), PROMO_CAP);
        total = Math.max(1000, harga - diskon); catatan = 'VOUCHER ' + vch + ' (-' + PROMO_PCT + '%)';
      } else { diskon = 0; total = harga; catatan = 'VOUCHER DITOLAK ' + vch.slice(0, 12); }
    }
    if (!(total >= 0 && total <= 1e9)) return json({ success: false, error: 'Total tidak valid' }, 400);
    const s = await currentSession(request, env);
    const email = s ? s.user.email : '';
    await ensureOrders(db);
    const now = Math.floor(Date.now() / 1000);
    let inv = '';
    for (let i = 0; i < 5; i++) {
      inv = newInvoice();
      try {
        await db.prepare('INSERT INTO pesanan (invoice,email,wa,produk,paket,uid,zone,nick,harga,diskon,total,metode,extra,status,catatan,dibuat,diubah) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
          .bind(inv, email, wa, produk, paket, String(b.uid || '').slice(0, 40), String(b.zone || '').slice(0, 20), String(b.nick || '').slice(0, 60), harga, diskon, total, String(b.metode || '').slice(0, 40), String(b.extra || '').slice(0, 300), 'menunggu', catatan, now, now).run();
        return json({ success: true, invoice: inv });
      } catch (e) { if (!/UNIQUE/i.test(String(e.message))) throw e; }
    }
    return json({ success: false, error: 'Gagal membuat invoice' }, 500);
  } catch (e) { return json({ success: false, error: 'Gagal menyimpan pesanan' }, 500); }
}
async function handleOrderCheck(request, env, url) {
  try {
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    const ip = clientIp(request) || 'x';
    if (await tooManyD(env, 'chk:' + ip, 30, 60000)) return json({ success: false, error: 'Terlalu banyak pengecekan. Tunggu sebentar.' }, 429);
    await noteFailD(env, 'chk:' + ip, 60000);
    const inv = String(url.searchParams.get('inv') || '').trim().toUpperCase();
    if (!/^JK\d{6}-[A-Z2-9]{6}$/.test(inv)) return json({ success: false, error: 'Format invoice tidak valid (contoh: JK261010-AB3CD4)' }, 400);
    await ensureOrders(db);
    const r = await db.prepare('SELECT * FROM pesanan WHERE invoice=?').bind(inv).first();
    if (!r) return json({ success: false, error: 'Invoice tidak ditemukan' }, 404);
    return json({ success: true, order: { invoice: r.invoice, produk: r.produk, paket: r.paket, uid: maskMid(r.uid), zone: r.zone, wa: maskMid(r.wa), total: r.total, metode: r.metode, status: r.status, catatan: r.catatan || '', dibuat: r.dibuat, diubah: r.diubah } });
  } catch (e) { return json({ success: false, error: 'Gagal memeriksa pesanan' }, 500); }
}
async function handleOrderMine(request, env) {
  try {
    const s = await currentSession(request, env);
    if (!s) return json({ success: false, error: 'Belum masuk' }, 401);
    const db = dbOf(env); if (!db) return json({ success: false, error: 'DB error' }, 500);
    await ensureOrders(db);
    const rs = await db.prepare('SELECT invoice,produk,paket,total,metode,status,dibuat FROM pesanan WHERE email=? ORDER BY id DESC LIMIT 50').bind(s.user.email).all();
    return json({ success: true, orders: rs.results || [] });
  } catch (e) { return json({ success: false, error: 'Gagal memuat riwayat' }, 500); }
}
async function handleOrderAdmin(request, env, url) {
  const d = await requireOwner(request, env); if (d) return d;
  try {
    const db = dbOf(env); await ensureOrders(db);
    const st = String(url.searchParams.get('status') || '');
    const rs = ORDER_STATUS.indexOf(st) >= 0
      ? await db.prepare('SELECT * FROM pesanan WHERE status=? ORDER BY id DESC LIMIT 200').bind(st).all()
      : await db.prepare('SELECT * FROM pesanan ORDER BY id DESC LIMIT 200').all();
    const cs = await db.prepare('SELECT status, COUNT(*) n FROM pesanan GROUP BY status').all();
    const counts = {}; (cs.results || []).forEach(x => { counts[x.status] = x.n; });
    return json({ success: true, orders: rs.results || [], counts });
  } catch (e) { return json({ success: false, error: 'Gagal memuat pesanan' }, 500); }
}
async function handleOrderStatus(request, env) {
  const d = await requireOwner(request, env); if (d) return d;
  try {
    const db = dbOf(env); await ensureOrders(db);
    const b = await request.json();
    const inv = String(b.invoice || '').toUpperCase(), st = String(b.status || '');
    if (ORDER_STATUS.indexOf(st) < 0) return json({ success: false, error: 'Status tidak valid' }, 400);
    const r = await db.prepare('UPDATE pesanan SET status=?, catatan=?, diubah=? WHERE invoice=?').bind(st, String(b.catatan || '').slice(0, 200), Math.floor(Date.now() / 1000), inv).run();
    if (r.meta && r.meta.changes === 0) return json({ success: false, error: 'Invoice tidak ditemukan' }, 404);
    return json({ success: true });
  } catch (e) { return json({ success: false, error: 'Gagal mengubah status' }, 500); }
}

/* ====================== LOGIN DISCORD (OAuth2) ======================
   Variabel Cloudflare: DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET (secret).
   Redirect URI di Discord Developer Portal: https://jkadistore.shop/api/auth/discord/callback
   Owner TIDAK bisa masuk lewat Discord (wajib email+sandi+OTP). */
function safeNextPath(n) { n = String(n || '/'); return (/^\/(?!\/)[A-Za-z0-9_\-\/\.?=&%]*$/.test(n)) ? n : '/'; }
function discordRedirectUri(env, url) { return env.DISCORD_REDIRECT || (url.origin + '/api/auth/discord/callback'); }
function authBack(request, msg, next) {
  const h = new Headers({ 'Location': '/?auth=login&auth_error=' + encodeURIComponent(msg) + (next ? '&next=' + encodeURIComponent(next) : ''), 'Cache-Control': 'no-store' });
  h.append('Set-Cookie', 'jka_ost=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''));
  return new Response(null, { status: 302, headers: h });
}
async function handleDiscordStart(request, env, url) {
  if (!env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET) return json({ success: false, error: 'Login Discord belum dikonfigurasi di server ini' }, 503);
  const next = safeNextPath(url.searchParams.get('next'));
  const nonce = otp6() + otp6() + otp6();
  const st = await makeToken(env, { e: 'oauth@state', r: 'user', i: nonce, n: next, x: Math.floor(Date.now() / 1000) + 600 });
  const q = new URLSearchParams({ client_id: env.DISCORD_CLIENT_ID, redirect_uri: discordRedirectUri(env, url), response_type: 'code', scope: 'identify email', state: nonce, prompt: 'none' });
  const h = new Headers({ 'Location': 'https://discord.com/oauth2/authorize?' + q.toString(), 'Cache-Control': 'no-store' });
  h.append('Set-Cookie', 'jka_ost=' + encodeURIComponent(st) + '; Path=/; Max-Age=600; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''));
  return new Response(null, { status: 302, headers: h });
}
async function handleDiscordCallback(request, env, url) {
  try {
    if (!env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET) return authBack(request, 'Login Discord belum dikonfigurasi');
    const st = await readToken(env, readCookie(request, 'jka_ost'));
    const state = url.searchParams.get('state') || '', code = url.searchParams.get('code') || '';
    if (url.searchParams.get('error')) return authBack(request, 'Login Discord dibatalkan');
    if (!st || !state || st.i !== state || !code) return authBack(request, 'Sesi login Discord tidak valid. Coba lagi.');
    const next = safeNextPath(st.n);
    const tr = await fetch('https://discord.com/api/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_id: env.DISCORD_CLIENT_ID, client_secret: env.DISCORD_CLIENT_SECRET, grant_type: 'authorization_code', code: code, redirect_uri: discordRedirectUri(env, url) }).toString() });
    if (!tr.ok) return authBack(request, 'Gagal menghubungi Discord', next);
    const tk = await tr.json();
    const ur = await fetch('https://discord.com/api/users/@me', { headers: { 'Authorization': 'Bearer ' + tk.access_token } });
    if (!ur.ok) return authBack(request, 'Gagal membaca akun Discord', next);
    const du = await ur.json();
    const email = String(du.email || '').toLowerCase().trim();
    if (!email || !du.verified) return authBack(request, 'Email Discord belum terverifikasi. Verifikasi dulu di Discord.', next);
    if (email === OWNER_EMAIL) return authBack(request, 'Akun owner wajib masuk dengan email, sandi & kode OTP.', next);
    const db = dbOf(env); if (!db) return authBack(request, 'Database error', next);
    const nm = cleanName(du.global_name || du.username || email.split('@')[0]) || 'Member';
    const av = du.avatar ? 'https://cdn.discordapp.com/avatars/' + du.id + '/' + du.avatar + '.png?size=128' : '';
    let row = await db.prepare('SELECT id, status_aktif FROM pengguna WHERE email = ?').bind(email).first();
    if (!row) {
      const uid = 'U-' + Date.now().toString(36) + '-' + b64uEnc(crypto.getRandomValues(new Uint8Array(6))).replace(/[^A-Za-z0-9]/g, 'x');
      const rnd = 'nologin$' + b64uEnc(crypto.getRandomValues(new Uint8Array(24)));   // akun sosial: tidak bisa login dengan sandi sampai pemilik membuat sandi sendiri
      await db.prepare('INSERT INTO pengguna (id, email, kata_sandi, peran, nama, saldo_koin, tanggal_daftar, status_aktif) VALUES (?, ?, ?, ?, ?, 0, ?, 1)').bind(uid, email, rnd, 'user', nm, new Date().toISOString()).run();
      if (av) { try { await db.prepare('UPDATE pengguna SET avatar=? WHERE email=?').bind(av, email).run(); } catch (e) {} }
      row = { id: uid, status_aktif: 1 };
    } else if (!row.status_aktif) {
      await db.prepare('UPDATE pengguna SET status_aktif=1 WHERE email=?').bind(email).run();
    }
    try { await db.prepare('UPDATE pengguna SET terakhir_login=? WHERE email=?').bind(new Date().toISOString(), email).run(); } catch (e) {}
    const token = await makeToken(env, { e: email, r: 'user', i: row.id, x: Math.floor(Date.now() / 1000) + TTL_USER });
    const h = new Headers({ 'Location': next, 'Cache-Control': 'no-store' });
    h.append('Set-Cookie', sessionCookie(request, token, TTL_USER));
    h.append('Set-Cookie', 'jka_ost=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax' + (isHttps(request) ? '; Secure' : ''));
    return new Response(null, { status: 302, headers: h });
  } catch (e) { return authBack(request, 'Login Discord gagal. Coba lagi.'); }
}

const APP = {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (path.indexOf('/_dokumen') === 0) return new Response('Not found', { status: 404 });
    if (path.indexOf('/api/') === 0 && method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS' && !originOk(request, url)) {
      return json({ success: false, error: 'Permintaan ditolak: asal tidak dikenal.' }, 403);
    }

    // === AUTH ===
    if (path === '/api/captcha' && method === 'GET') return handleCaptcha(env);
    if (path === '/api/auth/avatar' && method === 'POST') return handleAvatarUpload(request, env);
    if (path.indexOf('/api/avatar/') === 0 && method === 'GET') return handleAvatarGet(env, path.slice(12));
    if (path === '/api/auth/login' && method === 'POST') {
      try {
        const lb = await request.json();
        const had = await capPassOk(request, env, lb.email);
        if (!had && !(await botOk(request, env, lb))) return BOT_FAIL();
        const { email, password } = lb;
        return withCapPass(request, env, await handleOtpSend(new Request(request.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        }), env), email);
      } catch(e) { return json({ success: false, error: GENERIC_ERR }, 500); }
    }
    if ((path === '/api/auth/register' || path === '/api/auth/forgot') && method === 'POST') {
      const cb = await request.clone().json().catch(() => ({}));
      const regPass = path === '/api/auth/register' && await capPassOk(request, env, cb.email);
      if (!regPass && !(await botOk(request, env, cb))) return BOT_FAIL();
      return path === '/api/auth/register' ? withCapPass(request, env, await handleRegister(request, env), cb.email) : handleForgot(request, env);
    }
    if (path === '/api/auth/forgot/verify' && method === 'POST') return handleForgotVerify(request, env);
    if (path === '/api/auth/logout') return handleLogout(request, env);
    if (path === '/api/auth/session' && (method === 'GET' || method === 'HEAD')) {
      const r = await handleSession(request, env);
      if (r) return r;               // sesi OTP valid
      /* tak ada sesi OTP -> lanjut ke ORIGIN (sesi login sosial lama), lihat proxy di bawah */
    }
    if (path === '/api/auth/profile' && method === 'POST') return handleProfile(request, env);
    if (path === '/api/auth/password' && method === 'POST') return handlePassword(request, env);
    if (path.startsWith('/api/promo/')) return handlePromo(request, env, path);
    if (path === '/api/orders' && method === 'POST') return handleOrderCreate(request, env);
    if (path === '/api/orders/check' && method === 'GET') return handleOrderCheck(request, env, url);
    if (path === '/api/orders/mine' && method === 'GET') return handleOrderMine(request, env);
    if (path === '/api/orders/admin' && method === 'GET') return handleOrderAdmin(request, env, url);
    if (path === '/api/orders/status' && method === 'POST') return handleOrderStatus(request, env);
    if (path === '/api/auth/discord' && method === 'GET') return handleDiscordStart(request, env, url);
    if (path === '/api/auth/discord/callback' && method === 'GET') return handleDiscordCallback(request, env, url);
    if (path === '/api/auth/owner/password') return json({ success: false, error: 'Sandi owner disimpan di Cloudflare (variabel OWNER_SHA256). Ganti lewat Settings > Variables and secrets.' }, 400);

    // === OTP ===
    if (path === '/api/otp/send' && method === 'POST') {
      const ob = await request.clone().json().catch(() => ({}));
      if (!(await capPassOk(request, env, ob.email))) return BOT_FAIL();
      return handleOtpSend(request, env);
    }
    if (path === '/api/otp/verify' && method === 'POST') return handleOtpVerify(request, env);

    // === REPORT ===
    if (path === '/api/report/send' && method === 'POST') return handleReport(request, env);

    // === SERTIFIKAT: layani langsung dari aset (tidak bergantung ORIGIN) ===
    if (path.startsWith('/keys/')) return env.ASSETS.fetch(request);

    // === PENJAGA ROUTE OWNER: role dicek DI SERVER ===
    if (isOwnerRoute(path, method)) {
      const s = await currentSession(request, env);
      if (s) { if (s.user.role !== 'owner') return json({ success: false, error: 'Akses ditolak: khusus owner' }, 403); }
      else if (!readCookie(request, 'jka_session')) return json({ success: false, error: 'Belum masuk' }, 401);
    }

    // === PROXY ke ORIGIN ===
    if (path.startsWith('/api/')) {
      const target = ORIGIN + path + url.search;
      const h = new Headers(request.headers);
      h.set('Host', new URL(ORIGIN).hostname);
      const init = {
        method: method,
        headers: h,
        body: ['GET', 'HEAD'].includes(method) ? undefined : request.body,
        redirect: 'manual'
      };
      try { return await fetch(new Request(target, init)); } catch (e) { return json({ success: false, error: 'Layanan sementara tidak tersedia' }, 502); }
    }

    return env.ASSETS.fetch(request);
  }
};

// Header keamanan sungguhan (tag <meta> tidak berfungsi untuk ini)
function withSec(res, request) {
  try {
    if (res.status === 101) return res;
    const r = new Response(res.body, res);
    r.headers.set('X-Content-Type-Options', 'nosniff');
    try { if (new URL(request.url).pathname.indexOf('/api/') === 0 && !r.headers.has('Content-Security-Policy')) r.headers.set('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'"); } catch (e) {}
    r.headers.set('X-Frame-Options', 'SAMEORIGIN');
    r.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    r.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    if (isHttps(request)) r.headers.set('Strict-Transport-Security', 'max-age=31536000');
    return r;
  } catch (e) { return res; }
}
export default {
  async fetch(request, env, ctx) { return withSec(await APP.fetch(request, env, ctx), request); }
};
