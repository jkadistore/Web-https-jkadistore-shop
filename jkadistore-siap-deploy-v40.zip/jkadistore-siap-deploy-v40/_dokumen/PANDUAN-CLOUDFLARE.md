# PANDUAN CLOUDFLARE — JK ADISTORE
Centang satu per satu. Urutan sudah disusun supaya tidak ada langkah yang saling menunggu.
JANGAN kirim isi secret (kunci/sandi) ke chat AI mana pun. Isi langsung di dashboard Cloudflare.

## A. Proyek Pages
1. Cloudflare > Workers & Pages > proyek situs (jkadistore). Build command: kosong. Output directory: folder berisi `index.html` dan `_worker.js` (root zip ini).
2. Deploy: upload isi zip (Direct Upload) atau sambungkan GitHub. File `_worker.js`, `_routes.json`, `_headers` HARUS ada di root.
3. Setelah deploy, buka `Ctrl+Shift+R` (hard refresh) di situs untuk memastikan versi baru terbaca.

## B. Database D1 (Settings > Bindings)
Tambah binding D1 (Production DAN Preview):
| Variable name | Database |
|---|---|
| `DB_MAIN` | `jkadistore-db` |
(Cukup `DB_MAIN`. Nama lama `DB_AI` / `DB_FOTO` hanya dipakai sebagai cadangan bila `DB_MAIN` tidak ada.)
Tabel `ratelimit`, `avatars`, `pesanan` dibuat otomatis oleh worker. `pengguna` dan `log_login` sudah ada dari sebelumnya.
Aktifkan backup: D1 > jkadistore-db > Time Travel (cek berkala).

## C. Variables and Secrets (Settings > Variables and Secrets)
| Nama | Tipe | Isi |
|---|---|---|
| `SESSION_SECRET` | Secret | Teks acak >= 40 karakter. Jangan diganti-ganti (semua user ter-logout). |
| `OWNER_SHA256` | Secret | SHA-256 dari sandi owner BARU. |
| `RESEND_API_KEY` | Secret | Kunci Resend untuk kirim OTP email. |
| `TURNSTILE_SITEKEY` | Text | Site key Turnstile (publik). |
| `TURNSTILE_SECRET` | Secret | Secret key Turnstile. |
| `DISCORD_CLIENT_ID` | Text | Dari Discord Developer Portal. |
| `DISCORD_CLIENT_SECRET` | Secret | Dari Discord Developer Portal. |
| `DISCORD_REDIRECT` | Text | `https://jkadistore.shop/api/auth/discord/callback` |
| `PBKDF2_ITER` | Text (opsional) | `100000` (hanya paket Workers berbayar). |
Cara membuat SHA-256 sandi owner: buka https://emn178.github.io/online-tools/sha256.html , ketik sandi, salin hasil heksadesimalnya.
Setelah mengubah variabel: deploy ulang (variabel baru hanya berlaku di deployment berikutnya).

## D. Turnstile (anti-bot)
Cloudflare > Turnstile > Add site > domain `jkadistore.shop` (+ subdomain yang dipakai). Mode Managed. Salin Site key + Secret ke bagian C. Detail: `PASANG-CLOUDFLARE-TURNSTILE.txt`.

## E. Resend (email OTP)
Resend > Domains > verifikasi `jkadistore.shop` (tambahkan record DNS SPF/DKIM yang diminta, di Cloudflare DNS, status DNS only/abu-abu). Buat API key, taruh di `RESEND_API_KEY`. Kalau kunci pernah terkirim lewat chat/screenshot: hapus dan buat ulang.

## F. Discord login
Discord Developer Portal > aplikasi > OAuth2 > Redirects: tambahkan `https://jkadistore.shop/api/auth/discord/callback` (harus sama persis dengan `DISCORD_REDIRECT`).

## G. Domain & SSL
1. Pages > Custom domains: `jkadistore.shop` (dan `www` bila dipakai). Subdomain lain (`ai.`, `app.`) bila masih dipakai.
2. SSL/TLS > Overview: **Full (strict)**.
3. SSL/TLS > Edge Certificates: **Always Use HTTPS** = On; HSTS sudah dikirim dari `_headers`.

## H. Keamanan Cloudflare
1. Security > WAF > Rate limiting rules: path mulai `/api/auth/` — mis. 20 permintaan/menit per IP, aksi Block.
2. Security > Bots > **Bot Fight Mode** = On.
3. Aktifkan 2FA di akun Cloudflare, Resend, GitHub, dan email owner.

## I. Setelah SETIAP deploy
1. Caching > Configuration > **Purge Everything** (agar pengunjung tidak melihat file lama).
2. Hard refresh, lalu tes cepat (bagian J).

## J. Tes setelah deploy
- Beranda terbuka, produk tampil, ganti bahasa lewat ikon globe.
- Daftar akun baru: OTP email masuk.
- Login owner (email + sandi + OTP).
- Buka produk game > isi User ID > pesan: invoice `JKyymmdd-XXXXXX` muncul dan WhatsApp terbuka.
- Cek Transaksi: masukkan invoice tadi, status tampil.
- `https://jkadistore.shop/_dokumen/README.md` harus **404** (normal).

## K. Masalah umum
| Gejala | Penyebab / solusi |
|---|---|
| Tampilan lama setelah deploy | Purge cache + hard refresh. |
| Error 500 / "Layanan sedang bermasalah" di /api | Binding `DB_MAIN` belum ada atau belum deploy ulang setelah dibuat. |
| OTP tidak masuk | `RESEND_API_KEY` salah / domain Resend belum verified / cek folder spam. |
| Captcha/Turnstile gagal | Domain belum ditambahkan di Turnstile, atau sitekey/secret tertukar. |
| Login Discord "redirect_uri" salah | Redirect di Discord tidak sama persis dengan `DISCORD_REDIRECT`. |
| Semua user tiba-tiba logout | `SESSION_SECRET` berubah. |
| Fitur lama (/api/store/*) mati | Server lama (ORIGIN `https://25bd5ade.jkadistore.pages.dev`) tidak boleh dihapus dulu; endpoint itu masih diteruskan ke sana. |
