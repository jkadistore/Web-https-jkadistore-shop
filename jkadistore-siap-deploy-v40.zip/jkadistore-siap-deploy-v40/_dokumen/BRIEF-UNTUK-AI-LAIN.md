# BRIEF UNTUK AI LAIN (salin semua teks di bawah garis, tempel di awal chat)
Lampirkan juga zip situs dan file `_dokumen/PANDUAN-LENGKAP.md`.

---
Kamu membantu mengerjakan situs "JK ADISTORE" (jkadistore.shop), toko top up game & produk digital milik saya, berbahasa Indonesia. Balas dalam bahasa Indonesia, sederhana, saya bukan programmer.

KONTEKS TEKNIS
- Cloudflare Pages mode advanced: `_worker.js` + `_routes.json` + `_headers`. HTML/JS statis tanpa build.
- Database D1 `jkadistore-db` (binding `DB_MAIN`). OTP via Resend, anti-bot Turnstile, login Discord.
- Data produk ada di `index.html` (`window.JK_LOCAL_DATA.products`). Checkout game di `assets/topup.js`, promo harian di `assets/promo-harian.js` + `_worker.js`, bahasa di `assets/i18n-data.js`.
- Endpoint lama (`/api/store/*`, `/api/site-status`, `/api/auth/owner/*`) diteruskan ke `https://25bd5ade.jkadistore.pages.dev`. Jangan dihapus/diubah tanpa rencana migrasi.
- Baca `PANDUAN-LENGKAP.md` dan `PANDUAN-CLOUDFLARE.md` sebelum mengubah apa pun.

ATURAN WAJIB
1. Jangan melemahkan keamanan: hashing sandi, OTP ter-hash, rate limit, cek Origin, header keamanan, `/_dokumen/*` tetap 404.
2. Jangan minta atau menulis secret (API key, sandi, SESSION_SECRET) ke chat/kode. Secret hanya diisi di dashboard Cloudflare.
3. Setiap ubah file di `assets/`, naikkan `?v=` di tag HTML yang memuatnya.
4. Jangan buat data palsu (ulasan, sertifikat, logo merek) tanpa memberi tahu saya.
5. Setiap tambah teks tampilan baru, tambahkan terjemahannya di `assets/i18n-data.js`.
6. Jangan menimpa file saya tanpa menjelaskan apa yang berubah; sebutkan file yang kamu ubah.
7. Jujur: kalau tidak bisa memverifikasi sesuatu (butuh internet/perangkat asli), katakan.

SETELAH SELESAI
Kirim zip baru + ringkasan singkat: file yang berubah, apa yang harus saya lakukan di Cloudflare (deploy ulang, purge cache, variabel baru), dan cara mengetesnya.

TUGAS SAYA SEKARANG:
(tulis permintaanmu di sini)
---
