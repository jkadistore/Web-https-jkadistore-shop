# JK-ADISTORE-
## v10 — AI: 810 produk, info transaksi WA 628991232005, data publik dibersihkan; v9 — perbaikan ticker/ikon kategori; v8 — Cek Transaksi, Kalkulator, Invoice
- Menu drawer baru: **Cek Transaksi** (`/cek-transaksi`) dan **Kalkulator** (`/kalkulator?t=wr|gacha`).
- Checkout membuat invoice `JKyymmdd-XXXXXX` (tabel D1 `pesanan` dibuat otomatis), lalu membuka WhatsApp toko dengan nomor invoice.
- Owner: panel > tab **Pesanan** untuk mengubah status (menunggu/diproses/berhasil/gagal/dibatalkan) + catatan.
- User: Riwayat Pesanan membaca dari server. Setelah deploy, tetap set `SESSION_SECRET` dan `OWNER_SHA256`.

## v11 — Login Discord + modal login di tengah
Set di Cloudflare (Pages > Settings > Variables): `DISCORD_CLIENT_ID` dan `DISCORD_CLIENT_SECRET` (secret).
Di Discord Developer Portal > OAuth2 > Redirects tambahkan: `https://jkadistore.shop/api/auth/discord/callback`.
Owner tidak bisa masuk lewat Discord (wajib email + sandi + OTP).

## v12 — Palet biru seragam + banner animasi di dasbor utama
Banner (3 gambar baru, biru) tampil paling atas dengan zoom halus, kilau, caption bertahap, dan indikator progres. Animasi muncul saat scroll bersifat ringan dan mengikuti `prefers-reduced-motion`.

## Multi bahasa
- Pilihan: Indonesia, English, Bahasa Melayu, 简体中文, Filipino (tombol globe di header).
- Pengunjung baru otomatis diberi bahasa sesuai bahasa browser-nya; pilihan disimpan dan ikut ke halaman lain.
- Kamus ada di assets/i18n-data.js (kunci = teks Indonesia). Mau menambah/mengubah terjemahan, tambahkan atau ubah barisnya di sana.
- Nama produk, deskripsi produk, dan pesan WhatsApp ke admin tetap Indonesia.

## Panduan
- `PANDUAN-LENGKAP.md`: cara kerja situs & peta file.
- `PANDUAN-CLOUDFLARE.md`: daftar centang apa yang dikerjakan di Cloudflare.
- `BRIEF-UNTUK-AI-LAIN.md`: teks siap tempel kalau pakai AI lain.

## v40 — Audit final
Semua halaman, tombol, bahasa, detail produk (semua kategori), tes keamanan dan API sudah diperiksa ulang tanpa error. Perbaikan: alat pasang logo tidak lagi melebar di HP.
