# PANDUAN LENGKAP — JK ADISTORE
Dokumen ini menjelaskan cara kerja situs supaya kamu atau AI lain bisa melanjutkan tanpa bingung.
Untuk langkah di Cloudflare lihat `PANDUAN-CLOUDFLARE.md`. Untuk brief siap tempel ke AI lain lihat `BRIEF-UNTUK-AI-LAIN.md`.

## 1. Arsitektur singkat
- Situs statis (HTML/CSS/JS biasa, tanpa framework/build) di Cloudflare Pages + `_worker.js` (mode advanced).
- `_routes.json`: hanya `/api/*`, `/keys/*`, `/_dokumen/*` yang dijalankan worker; sisanya file statis langsung.
- Database: Cloudflare D1 `jkadistore-db` (binding `DB_MAIN`).
- Email OTP: Resend. Anti-bot: Turnstile. Login sosial: Discord.
- Endpoint lama (`/api/store/*`, `/api/site-status`, `/api/auth/owner/*`) diteruskan worker ke ORIGIN lama `https://25bd5ade.jkadistore.pages.dev`. Jangan matikan sebelum dipindahkan.

## 2. Peta file
| File | Fungsi |
|---|---|
| `_worker.js` | Semua API baru: auth, OTP, pesanan (`/api/orders`), promo (`/api/promo/*`), foto profil, proxy ke server lama, header keamanan. |
| `_headers` | Header keamanan/cache file statis (CSP, HSTS, dll). |
| `index.html` | Beranda + DATA PRODUK (`window.JK_LOCAL_DATA.products`). |
| `assets/app.js`, `store-sync.js` | Logika toko, sinkron data dengan server. |
| `assets/topup.js` + `topup.css` | Overlay checkout game (cek User ID, pilih paket, diskon, bayar, kirim WhatsApp). |
| `assets/promo-harian.js` | Banner & kode voucher diskon harian 30%. |
| `assets/i18n.js`, `i18n-data.js` | Multi bahasa (id, en, ms, zh, tl). |
| `assets/theme-kuy.css/js` | Tema biru, panel kepercayaan (#sertifikat), centang biru, chip statistik. |
| `assets/polish.js/css` | Perapian tombol/ikon. |
| `assets/owner-*.js`, `admin-clean.js` | Panel owner/admin. |
| `assets/auth-core.js`, `login.html` | Login/daftar. |
| `images/` | Foto produk (webp 800x800). |
| `tools/` | Alat bantu dibuka di browser (pasang logo resmi, buat kunci sertifikat). |
| `keys/` | Kunci publik sertifikat. Kunci privat JANGAN pernah di sini. |
| `_dokumen/` | Dokumentasi (diblokir 404 di situs). |

## 3. Mengubah hal yang sering
- **Produk & harga**: `index.html` > `window.JK_LOCAL_DATA.products`. Field: `id, name, cat, price, old, stok, sold, img, desc, badge, priceList`. `priceList` = daftar paket (nama + harga). Foto: `images/xxx.webp` 800x800.
- **SCRIP GG**: 8 produk (V1.0–V8.0), kategori `Scrip & Tools Game`, masing-masing paket 3/7/30 Hari. Harga V2–V8 untuk 3/7 hari adalah perkiraan proporsional; sesuaikan dengan harga resmi.
- **Promo harian**: kode & produk terpilih diturunkan otomatis dari tanggal WIB oleh server (HMAC `SESSION_SECRET`). Diskon 30%, maksimum Rp 50.000, ±1,5% produk game per hari. Ubah di `_worker.js`: `PROMO_PCT`, `PROMO_CAP`, `PROMO_RATE`. Hanya produk game/top-up (checkout `topup.js`).
- **Bahasa**: kamus di `assets/i18n-data.js` (kunci = teks Indonesia persis). Tambah baris untuk teks baru. Nama/deskripsi produk dan pesan WhatsApp tetap Indonesia.
- **Logo/foto produk**: buka `tools/pasang-logo-resmi.html` di browser (lihat `CARA-PASANG-LOGO-RESMI.txt`, `CARA-PASANG-FOTO-ASLI.txt`).
- **Panel kepercayaan**: bagian `#sertifikat` di `index.html` (statistik, identitas toko, sosial media).

## 4. Alur pesanan
1. Pelanggan pilih produk game > overlay `topup.js` (User ID > paket > diskon & pembayaran).
2. Browser POST `/api/orders` > worker menyimpan ke tabel `pesanan` (invoice `JKyymmdd-XXXXXX`), menghitung ulang diskon voucher di server.
3. Browser membuka WhatsApp admin dengan isi invoice. Admin konfirmasi manual.
4. Produk non-game masih memakai alur lama (saldo, tanpa kolom voucher).
**Penting**: harga dasar masih dikirim dari browser; admin wajib mencocokkan nominal saat konfirmasi.

## 5. Aturan cache-bust
Setiap mengubah file di `assets/`, naikkan `?v=...` pada tag `<script>`/`<link>` di semua halaman HTML yang memakainya (format `YYYYMMDD-HHMM`). Kalau tidak, pengunjung bisa tetap memakai file lama.

## 6. Keamanan (jangan dilemahkan)
PBKDF2 untuk sandi, OTP di-hash HMAC, rate limit di D1, cek Origin (CSRF), header keamanan via `withSec`, `/_dokumen/*` = 404, error 500 generik. Detail: `KEAMANAN.txt`. Jangan taruh secret di kode, chat, atau screenshot.

## 7. Cara tes lokal
Situs statis: `python3 -m http.server 8811` di folder proyek. API butuh worker + D1 sungguhan (atau tiruan); paling aman uji di Preview deployment Cloudflare.

## 8. Batasan yang jujur
- Ulasan, jumlah order, dan angka "terjual" per produk adalah data contoh; ganti dengan data asli.
- Centang biru adalah lencana buatan sendiri, bukan verifikasi pihak ketiga.
- Kode voucher harian bisa dipakai berulang pada hari yang sama (belum ada batas per nomor).
- Terjemahan ms/zh/tl belum dicek penutur asli.
- Logo merek asli harus dipasang sendiri lewat alat logo.
- Endpoint lama masih bergantung ke ORIGIN lama.
