/* Tema toko: tambah "Cara Order", badge kepercayaan, FAQ. Teks mudah diedit di array di bawah. */
(function () {
  var STEPS = [['Pilih produk', 'Cari game, voucher, atau layanan digital yang kamu mau.'], ['Isi data', 'Masukkan ID/akun sesuai yang diminta di halaman produk.'], ['Bayar', 'Pilih nominal lalu selesaikan pembayaran.'], ['Pesanan diproses', 'Pesanan dikerjakan setelah pembayaran terkonfirmasi.']];
  var TRUST = [['<svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>', 'Proses Cepat', 'Dikerjakan setelah bayar'], ['<svg viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>', 'Transaksi Aman', 'Data & pembayaran dijaga'], ['<svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>', 'CS Siap Bantu', 'Hubungi kami kapan saja'], ['<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>', 'Terpercaya', 'Toko digital sejak 2023']];
  var FAQ = [['Berapa lama pesanan diproses?', 'Pesanan dikerjakan setelah pembayaran terkonfirmasi. Lama proses bergantung jenis produk; kamu bisa cek status lewat Riwayat Pesanan.'], ['Apakah saya perlu membagikan password akun game?', 'Tidak untuk top up biasa. Cukup ID/akun sesuai kolom yang diminta. Jangan pernah membagikan password atau kode OTP ke siapa pun.'], ['Metode pembayaran apa yang tersedia?', 'Lihat pilihan pembayaran yang tampil saat checkout, termasuk QRIS dan top up saldo.'], ['Bagaimana jika pesanan belum masuk?', 'Hubungi CS dengan menyertakan bukti pembayaran dan ID pesanan, kami bantu cek secepatnya.'], ['Apakah transaksi di sini aman?', 'Login memakai verifikasi OTP email dan data akun dilindungi. Tetap waspada terhadap penipuan atas nama toko di luar situs resmi.']];
  function el(h) { var d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }
  function boot() {
    var shop = document.getElementById('shop'), main = document.getElementById('home'); if (!shop || !main) return;
    document.body.classList.add('kuy'); document.documentElement.classList.add('kuy');
    if (!document.getElementById('kSteps')) {
      shop.parentNode.insertBefore(el('<section class="wrap section k-sec" id="kSteps"><h2>🧭 Cara Order</h2><div class="k-steps">' + STEPS.map(function (s, i) { return '<div class="k-step"><b>' + (i + 1) + '</b><h3>' + s[0] + '</h3><p>' + s[1] + '</p></div>'; }).join('') + '</div></section>'), shop);
      shop.parentNode.insertBefore(el('<section class="wrap k-sec"><div class="k-trust">' + TRUST.map(function (t) { return '<div><i>' + t[0] + '</i><p style="margin:0"><strong>' + t[1] + '</strong><span>' + t[2] + '</span></p></div>'; }).join('') + '</div></section>'), shop);
    }
    if (!document.getElementById('kFaq')) {
      main.appendChild(el('<section class="wrap section k-sec k-faq" id="kFaq"><h2>❓ Pertanyaan Umum</h2>' + FAQ.map(function (f) { return '<details><summary>' + f[0] + '</summary><p>' + f[1] + '</p></details>'; }).join('') + '<div class="k-help"><p style="margin:0"><b>Masih bingung?</b><small>Tim kami siap bantu.</small></p><button onclick="jkNav(\'social\')">Hubungi CS</button></div></section>'));
    }
  }
  /* Jam: animasi RGB berhenti saat jam tidak terlihat atau tab di background (hemat baterai/CPU) */
  function clockGuard() {
    var c = document.getElementById('clockBlock'); if (!c || c._kg) return; c._kg = 1;
    var vis = true, tab = true;
    function apply() { c.classList.toggle('k-paused', !(vis && tab)); }
    if ('IntersectionObserver' in window) new IntersectionObserver(function (e) { vis = e[0].isIntersecting; apply(); }, { threshold: 0.01 }).observe(c);
    document.addEventListener('visibilitychange', function () { tab = !document.hidden; apply(); });
  }
  window.kSearch = function () {
    var s = document.getElementById('shop'); if (s) s.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(function () { var i = document.getElementById('searchInput'); if (i) i.focus({ preventScroll: true }); }, 450);
  };
  window.jkCS = function () { if (window.closeNav) window.closeNav(); var m = document.getElementById('jkCSMenu'); if (m) m.classList.add('show'); };
  /* Kolom ukuran di panel (placeholder "px/rem"): angka polos otomatis jadi "NNpx" supaya CSS tidak invalid */
  document.addEventListener('change', function (e) {
    var i = e.target;
    if (i && i.tagName === 'INPUT' && /px|rem/i.test(i.placeholder || '') && /^\d+(\.\d+)?$/.test(String(i.value).trim())) i.value = String(i.value).trim() + 'px';
  }, true);
  /* Live search: menyaring sambil mengetik (sebelumnya hanya saat menekan Enter) */
  var _st;
  function liveSearch() {
    clearTimeout(_st);
    _st = setTimeout(function () {
      if (typeof window.searchProducts === 'function') window.searchProducts();
    }, 220);
  }
  document.addEventListener('input', function (ev) { if (ev.target && ev.target.id === 'searchInput') liveSearch(); });

  window.kCalcToggle = function () {
    var b = document.getElementById('kCalcBtn'), m = document.getElementById('kCalcSub'); if (!b || !m) return;
    var open = m.style.display === 'none'; m.style.display = open ? '' : 'none'; b.setAttribute('aria-expanded', open ? 'true' : 'false');
  };
  /* ?cs=1 -> buka menu CS (dipakai tautan bantuan) */
  try { if (new URLSearchParams(location.search).get('cs') === '1') setTimeout(function () { window.jkCS && window.jkCS(); }, 800); } catch (e) {}
  /* ---- Pesanan owner (data server) ---- */
  var ORD_ST = ['menunggu', 'diproses', 'berhasil', 'gagal', 'dibatalkan'], ordFilter = '';
  function oEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function oRp(n) { return 'Rp' + Number(n || 0).toLocaleString('id-ID'); }
  function oDt(t) { try { return new Date(t * 1000).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return ''; } }
  function ordersManager() {
    var box = document.getElementById('adminContent'); if (!box) return;
    box.innerHTML = '<h2 style="font-size:22px;margin-bottom:4px">📦 Pesanan</h2><p class="muted" style="margin-bottom:8px">Pesanan dari checkout (invoice). Ubah status agar pembeli bisa melihatnya di Cek Transaksi.</p><div id="kOrdBar" class="kOrdBar"></div><div id="kOrdList" class="muted">Memuat…</div>';
    fetch('/api/orders/admin' + (ordFilter ? '?status=' + ordFilter : ''), { credentials: 'same-origin' }).then(function (r) { return r.json().catch(function () { return {}; }); }).then(function (j) {
      var list = document.getElementById('kOrdList'), bar = document.getElementById('kOrdBar'); if (!list || !bar) return;
      if (!j || !j.success) { list.textContent = (j && j.error) || 'Gagal memuat pesanan.'; return; }
      var c = j.counts || {}, tot = 0; ORD_ST.forEach(function (k) { tot += c[k] || 0; });
      bar.innerHTML = [['', 'Semua (' + tot + ')']].concat(ORD_ST.map(function (k) { return [k, k + ' (' + (c[k] || 0) + ')']; })).map(function (a) { return '<button type="button" data-f="' + a[0] + '" class="' + (a[0] === ordFilter ? 'on' : '') + '">' + a[1] + '</button>'; }).join('');
      Array.prototype.forEach.call(bar.querySelectorAll('button'), function (b) { b.onclick = function () { ordFilter = b.getAttribute('data-f'); ordersManager(); }; });
      if (!j.orders.length) { list.innerHTML = '<div class="k-empty">Belum ada pesanan.</div>'; return; }
      list.innerHTML = j.orders.map(function (o) {
        return '<div class="kOrd" data-inv="' + oEsc(o.invoice) + '"><div class="h"><b>' + oEsc(o.invoice) + '</b><span class="kBadge ' + oEsc(o.status) + '">' + oEsc(o.status) + '</span></div>'
          + '<div class="m">' + oEsc(o.produk) + ' · ' + oEsc(o.paket) + ' · <b>' + oRp(o.total) + '</b></div>'
          + '<div class="m">ID: ' + oEsc(o.uid) + (o.zone ? ' (' + oEsc(o.zone) + ')' : '') + (o.nick ? ' · ' + oEsc(o.nick) : '') + ' · WA: ' + oEsc(o.wa) + '</div>'
          + '<div class="m">' + oEsc(o.metode) + (o.extra ? ' · ' + oEsc(o.extra) : '') + ' · ' + oDt(o.dibuat) + '</div>'
          + '<div class="a"><select>' + ORD_ST.map(function (k) { return '<option value="' + k + '"' + (k === o.status ? ' selected' : '') + '>' + k + '</option>'; }).join('') + '</select><input maxlength="200" placeholder="Catatan (opsional)" value="' + oEsc(o.catatan || '') + '"><button type="button">Simpan</button></div></div>';
      }).join('');
      Array.prototype.forEach.call(list.querySelectorAll('.kOrd'), function (card) {
        card.querySelector('button').onclick = function () {
          var btn = this; btn.disabled = true; btn.textContent = '…';
          fetch('/api/orders/status', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ invoice: card.getAttribute('data-inv'), status: card.querySelector('select').value, catatan: card.querySelector('input').value }) })
            .then(function (r) { return r.json().catch(function () { return {}; }); })
            .then(function (x) { if (x && x.success) ordersManager(); else { btn.disabled = false; btn.textContent = 'Simpan'; alert((x && x.error) || 'Gagal menyimpan'); } })
            .catch(function () { btn.disabled = false; btn.textContent = 'Simpan'; alert('Koneksi bermasalah'); });
        };
      });
    }).catch(function () { var l = document.getElementById('kOrdList'); if (l) l.textContent = 'Koneksi bermasalah.'; });
  }
  function hookAdmin() {
    if (typeof window.adminNav !== 'function' || window.adminNav.__kOrd) return false;
    var orig = window.adminNav;
    var f = function (tab) { orig.apply(this, arguments); if (tab === 'orders') ordersManager(); };
    f.__kOrd = true; window.adminNav = f; return true;
  }
  var _hk = 0, _hi = setInterval(function () { hookAdmin(); if (++_hk > 40) clearInterval(_hi); }, 500);

  /* ---- Ticker berjalan: logo SVG sesuai nama (menggantikan teks "<img ...>" yang rusak) ---- */
  var MQ_P = {
    sword: '<path d="M14.5 3.5 20.5 3.5 20.5 9.5 10 20 7 17z"/><path d="M5 19l-2 2M8.5 15.5 6 13l2-2"/>',
    flame: '<path d="M12 3c1 3-2 4-2 7a3 3 0 0 0 6 0c0-1-.5-2-1-3 3 2 4 5 4 7a7 7 0 0 1-14 0c0-4 3-6 7-11z"/>',
    aim: '<circle cx="12" cy="12" r="8"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/>',
    star: '<path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/>',
    music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>',
    crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
    wallet: '<path d="M20 7H5a2 2 0 0 1 0-4h13v4z"/><path d="M3 5v14a2 2 0 0 0 2 2h15V7"/><circle cx="16.5" cy="14" r="1.2"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
    play: '<circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16"/>',
    plane: '<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    server: '<rect x="3" y="3" width="18" height="7" rx="2"/><rect x="3" y="14" width="18" height="7" rx="2"/><path d="M7 6.5h.01M7 17.5h.01"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    pin: '<path d="M12 22s7-6 7-12a7 7 0 0 0-14 0c0 6 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
    bag: '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/>',
    bolt: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10"/>',
    check: '<circle cx="12" cy="12" r="10"/><polyline points="8 12 11 15 16 9"/>'
  };
  var MQ_C = { sword: '#f59e0b', flame: '#fb923c', aim: '#facc15', star: '#a78bfa', music: '#22c55e', shield: '#60a5fa', crown: '#fbbf24', wallet: '#38bdf8', globe: '#22d3ee', play: '#f472b6', plane: '#38bdf8', server: '#94a3b8', chip: '#c084fc', pin: '#f87171', bag: '#818cf8', bolt: '#fde047', check: '#4ade80' };
  function mqKey(n) {
    n = String(n).toLowerCase();
    var map = [[/mlbb|mobile legend/, 'sword'], [/free ?fire|\bff\b/, 'flame'], [/pubg|valorant|cod\b|call of duty/, 'aim'], [/genshin|honkai|star rail/, 'star'], [/spotify|musik|music/, 'music'], [/vpn|aman|garansi/, 'shield'], [/premium/, 'crown'], [/wallet|dana|ovo|gopay|saldo/, 'wallet'], [/domain|website|web/, 'globe'], [/stream|netflix|youtube/, 'play'], [/telegram|whatsapp|bot/, 'plane'], [/vps|hosting|server|cloud/, 'server'], [/digital|ai\b|software|lisensi/, 'chip'], [/indonesia/, 'pin'], [/cepat|kilat|top ?up/, 'bolt'], [/amanah|terpercaya/, 'check']];
    for (var i = 0; i < map.length; i++) if (map[i][0].test(n)) return map[i][1];
    return 'bag';
  }
  function mqSvg(k) { return '<svg viewBox="0 0 24 24" fill="none" stroke="' + MQ_C[k] + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + MQ_P[k] + '</svg>'; }
  function mqItem(name) { return '<span class="mq">' + mqSvg(mqKey(name)) + oEsc(name) + '</span>'; }
  function worldNames() { return (STORE.worldList || []).map(function (w) { return String(w).replace(/<[^>]*>/g, '').replace(/^[^A-Za-z0-9]+/, '').trim(); }).filter(Boolean); }
  function kWorld() {
    var g = document.getElementById('worldGrid'); if (!g || typeof STORE === 'undefined') return;
    g.innerHTML = worldNames().map(function (n) { return '<div class="feature-tile"><div class="ic kWIc">' + mqSvg(mqKey(n)) + '</div><b>' + oEsc(n) + '</b><small>Terlengkap</small></div>'; }).join('');
  }
  function kMarquee() {
    var tr = document.getElementById('marqueeTrack'); if (!tr || typeof STORE === 'undefined') return;
    kWorld();
    var names = worldNames();
    names.push(STORE.name || 'JK ADISTORE', 'Top Up Cepat', 'Amanah Sejak 2023', 'Garansi 100%');
    var one = names.map(mqItem).join('');
    tr.innerHTML = one + one;
  }
  window.kMarquee = kMarquee;
  (function hookFeat() {
    var n = 0, iv = setInterval(function () {
      if (typeof window.renderFeatures === 'function' && !window.renderFeatures.__kMq) {
        var o = window.renderFeatures, f = function () { var r = o.apply(this, arguments); try { kMarquee(); } catch (e) {} return r; };
        f.__kMq = true; window.renderFeatures = f; kMarquee(); clearInterval(iv);
      } else if (++n > 60) clearInterval(iv);
    }, 250);
  })();


  /* ---- Scene SVG animasi untuk banner bawaan (ala storediamond) ---- */
  var K_DEFS = '<defs><linearGradient id="kg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d6ebff"/><stop offset="1" stop-color="#5da2ff"/></linearGradient><linearGradient id="kg2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5b97ff"/><stop offset="1" stop-color="#1c46b8"/></linearGradient><linearGradient id="kg3" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2c63e0"/><stop offset="1" stop-color="#0f2a78"/></linearGradient><linearGradient id="kg4" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ffe9a8"/><stop offset="1" stop-color="#ffbf3d"/></linearGradient><radialGradient id="kgl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#9cc8ff" stop-opacity=".55"/><stop offset="1" stop-color="#9cc8ff" stop-opacity="0"/></radialGradient></defs>';
  function kGem(cx, cy, s, cls) {
    return '<g class="' + cls + '"><g transform="translate(' + cx + ' ' + cy + ') scale(' + s + ')">'
      + '<polygon points="-20,-29 20,-29 38,-6 -38,-6" fill="url(#kg1)"/><polygon points="0,-40 -20,-29 20,-29" fill="#e8f3ff"/>'
      + '<polygon points="-38,-6 -20,-29 0,-40" fill="#7db4ff" opacity=".9"/><polygon points="38,-6 20,-29 0,-40" fill="#4c86ee" opacity=".95"/>'
      + '<polygon points="-38,-6 -18,-6 0,42" fill="url(#kg2)"/><polygon points="-18,-6 18,-6 0,42" fill="url(#kg3)"/><polygon points="38,-6 18,-6 0,42" fill="#16398f"/>'
      + '<path d="M-38 -6H38M-20 -29L-18 -6M20 -29L18 -6M0 -40V-29" stroke="#fff" stroke-opacity=".55" stroke-width="1" fill="none"/></g></g>';
  }
  function kSpark(x, y, r) { return '<path class="tw" d="M' + x + ' ' + (y - r) + 'L' + (x + r * .2) + ' ' + (y - r * .2) + 'L' + (x + r) + ' ' + y + 'L' + (x + r * .2) + ' ' + (y + r * .2) + 'L' + x + ' ' + (y + r) + 'L' + (x - r * .2) + ' ' + (y + r * .2) + 'L' + (x - r) + ' ' + y + 'L' + (x - r * .2) + ' ' + (y - r * .2) + 'Z" fill="#fff"/>'; }
  function kRays() { var o = ''; for (var i = 0; i < 8; i++) o += '<polygon points="150,70 ' + (150 + 120 * Math.cos(i * Math.PI / 4 - .09)) + ',' + (70 + 120 * Math.sin(i * Math.PI / 4 - .09)) + ' ' + (150 + 120 * Math.cos(i * Math.PI / 4 + .09)) + ',' + (70 + 120 * Math.sin(i * Math.PI / 4 + .09)) + '" fill="#fff" opacity=".07"/>'; return '<g class="ray">' + o + '</g>'; }
  var K_SCENES = [
    /* 1: top up game */
    K_DEFS + '<circle cx="150" cy="70" r="75" fill="url(#kgl)"/>' + kRays() + '<g class="big">' + kGem(150, 72, 1.45, 'fl') + '</g>' + kGem(72, 98, .55, 'fl2') + kGem(232, 40, .42, 'fl3')
      + '<g class="fl3"><g transform="translate(222 104)"><rect x="-17" y="-10" width="34" height="20" rx="9" fill="#10286f" stroke="#7db2ff" stroke-width="1.6"/><path d="M-9 -3v6M-12 0h6" stroke="#9cc8ff" stroke-width="2" stroke-linecap="round"/><circle cx="7" cy="-2" r="2" fill="#ffd166"/><circle cx="11" cy="2" r="2" fill="#7db2ff"/></g></g>'
      + kSpark(95, 30, 7) + kSpark(205, 18, 5) + kSpark(120, 124, 5) + kSpark(250, 78, 6) + kSpark(60, 60, 4),
    /* 2: premium & AI */
    K_DEFS + '<circle cx="150" cy="70" r="75" fill="url(#kgl)"/>' + kRays() + '<g class="big">' + kGem(150, 78, 1.25, 'fl') + '</g>'
      + '<g class="fl2"><g transform="translate(150 22)"><path d="M-24 8L-28 -12L-13 -2L0 -16L13 -2L28 -12L24 8Z" fill="url(#kg4)" stroke="#fff" stroke-opacity=".6" stroke-width="1"/><rect x="-24" y="8" width="48" height="6" rx="2" fill="#ffbf3d"/></g></g>'
      + '<g class="fl3"><g transform="translate(236 96)"><rect x="-15" y="-15" width="30" height="30" rx="7" fill="#10286f" stroke="#7db2ff" stroke-width="1.6"/><rect x="-7" y="-7" width="14" height="14" rx="3" fill="#2f63e0"/><path d="M-5 -15v-5M0 -15v-5M5 -15v-5M-5 15v5M0 15v5M5 15v5M-15 -5h-5M-15 0h-5M-15 5h-5M15 -5h5M15 0h5M15 5h5" stroke="#9cc8ff" stroke-width="1.6" stroke-linecap="round"/></g></g>'
      + kGem(66, 96, .5, 'fl3') + kSpark(90, 26, 6) + kSpark(214, 28, 6) + kSpark(250, 52, 4) + kSpark(110, 124, 5),
    /* 3: brand */
    K_DEFS + '<circle cx="150" cy="70" r="75" fill="url(#kgl)"/>' + kRays()
      + '<g class="orb"><ellipse cx="150" cy="70" rx="86" ry="30" fill="none" stroke="#9cc8ff" stroke-opacity=".5" stroke-width="1.4" stroke-dasharray="4 7" transform="rotate(-18 150 70)"/><circle cx="64" cy="86" r="5" fill="#ffd166"/></g>'
      + '<g class="big"><g class="fl"><path d="M150 18L204 38V76C204 104 180 122 150 132C120 122 96 104 96 76V38Z" fill="url(#kg2)" stroke="#9cc8ff" stroke-width="2"/><path d="M150 30L194 46V76C194 98 175 112 150 121C125 112 106 98 106 76V46Z" fill="url(#kg3)"/><path d="M128 76L144 92L174 58" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></g></g>'
      + kGem(236, 38, .5, 'fl2') + kGem(62, 40, .42, 'fl3') + kSpark(100, 120, 6) + kSpark(214, 112, 6) + kSpark(250, 84, 4) + kSpark(80, 70, 4)
  ];
  function kScenes() {
    var tr = document.getElementById('sliderTrack'); if (!tr) return;
    tr.querySelectorAll('.slide').forEach(function (s) {
      if (s.dataset.kScene) return; s.dataset.kScene = '1';
      var im = s.querySelector('img'), m = im && /banner-(\d)-/.exec(im.getAttribute('src') || ''); if (!m) return;
      var sc = K_SCENES[Number(m[1]) - 1]; if (!sc) return;
      var d = document.createElement('div'); d.className = 'kScene'; d.innerHTML = '<svg viewBox="0 0 280 140" preserveAspectRatio="xMidYMid meet" aria-hidden="true">' + sc + '</svg>';
      var cap = s.querySelector('.slide-caption'); s.insertBefore(d, cap || null);
      var c = document.createElement('span'); c.className = 'kCta'; c.textContent = ['Top Up sekarang juga →', 'Lihat promo →', 'Belanja aman →'][Number(m[1]) - 1] || 'Lihat produk →'; s.appendChild(c);
      var sh = document.createElement('i'); sh.className = 'kShine'; s.appendChild(sh);
    });
    tr.querySelectorAll('.slide a[href^="#"]').forEach(function (a) { a.removeAttribute('target'); a.onclick = function (e) { e.preventDefault(); var t = document.querySelector(a.getAttribute('href')) || document.getElementById('shop'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }; });
  }
  /* ---- Banner di paling atas + animasi (ala storediamond) ---- */
  function kSlideInit() {
    var home = document.getElementById('home'), hs = document.querySelector('.hero-slider');
    if (!home || !hs) return false;
    var wrap = hs.closest('.wrap');
    if (wrap && wrap.parentNode === home && home.firstElementChild !== wrap && !wrap.dataset.kTop) { wrap.dataset.kTop = '1'; wrap.style.marginTop = '12px'; home.insertBefore(wrap, home.firstElementChild); }
    return true;
  }
  function kMarkSlide() {
    var tr = document.getElementById('sliderTrack'); if (!tr) return;
    try { kScenes(); } catch (e) {}
    var dots = document.querySelectorAll('.slider-dots .dot'), cur = 0;
    dots.forEach(function (d, i) { if (d.classList.contains('active')) cur = i; });
    var spd = 6; try { spd = Math.max(3, Number(STORE.sliderSpeed) || 6); } catch (e) {}
    var sl = tr.querySelectorAll('.slide');
    sl.forEach(function (s, i) { s.classList.toggle('kOn', i === cur); });
    var sd = document.querySelector('.slider-dots'); if (sd) sd.style.setProperty('--kSpd', spd + 's');
    dots.forEach(function (d) { if (d.classList.contains('active')) { d.classList.remove('active'); void d.offsetWidth; d.classList.add('active'); } });
  }
  (function hookSlide() {
    var n = 0, iv = setInterval(function () {
      if (typeof window.goSlide === 'function' && !window.goSlide.__k && document.querySelector('.hero-slider .slide')) {
        var o = window.goSlide, f = function () { var r = o.apply(this, arguments); try { kMarkSlide(); } catch (e) {} return r; };
        f.__k = true; window.goSlide = f; kSlideInit(); kMarkSlide(); clearInterval(iv);
      } else if (++n > 80) clearInterval(iv);
    }, 250);
  })();

  /* ---- Diskon di beranda: produk dengan potongan harga terbesar (berganti tiap hari) ---- */
  function kPromo() {
    var home = document.getElementById('home'); if (!home) return false;
    var P = []; try { P = (typeof db !== 'undefined' && db.products) || []; } catch (e) {}
    try { var L = window.JK_LOCAL_DATA && window.JK_LOCAL_DATA.products; if (L && L.length > P.length) P = L; } catch (e) {}
    if (!P.length) return false;
    var seen = {}, list = P.filter(function (x) { return x && x.old > x.price && x.price > 0 && x.stok !== 0 && x.img && x.id; })
      .map(function (x) { x._pct = Math.round((1 - x.price / x.old) * 100); return x; }).filter(function (x) { return x._pct >= 5 && x._pct <= 90; })
      .sort(function (a, b) { return b._pct - a._pct || (b.sold || 0) - (a.sold || 0); })
      .filter(function (x) { var k = String(x.name).toLowerCase(); if (seen[k]) return false; seen[k] = 1; return true; });
    if (!list.length) return false;
    var top = list.slice(0, 40), day = Math.floor(Date.now() / 86400000), off = (day * 7) % Math.max(1, top.length - 11), pick = top.slice(off, off + 12).concat(top.slice(0, off).slice(0, 6));
    var maxp = pick.reduce(function (m, x) { return Math.max(m, x._pct); }, 0);
    var rp = function (n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); };
    var e = function (t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var html = '<div class="kPromoHead"><div><span class="kPromoTag"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13 2 4 14h6l-1 8 9-12h-6z"/></svg>Promo</span><h2>Diskon Hari Ini</h2><p>Hemat sampai <b>' + maxp + '%</b> untuk produk pilihan. Berganti setiap hari.</p></div><a class="kPromoAll" href="#shop" onclick="var t=document.getElementById(\'shop\');if(t){event.preventDefault();t.scrollIntoView({behavior:\'smooth\'})}">Lihat semua</a></div>'
      + '<div class="kPromoRow" role="list">' + pick.map(function (x) {
        var sold = Number(x.sold) || 0, bar = Math.min(96, Math.max(18, Math.round(sold / (sold + (x.stok || 5) * 8) * 100)));
        return '<article class="kPCard" role="listitem" onclick="openDetail(\'' + e(x.id) + '\')"><div class="kPImg"><img src="' + e(x.img) + '" alt="' + e(x.name) + '" loading="lazy" onerror="var c=this.closest(\'.kPCard\');if(c)c.remove()"><span class="kPOff">-' + x._pct + '%</span></div>'
          + '<div class="kPBody"><h3>' + e(x.name) + '</h3><div class="kPPrice"><b>' + rp(x.price) + '</b><s>' + rp(x.old) + '</s></div>'
          + '<div class="kPBar"><i style="width:' + bar + '%"></i></div><small>' + (sold ? 'Terjual ' + sold.toLocaleString('id-ID') : 'Stok terbatas') + '</small>'
          + '<button type="button" onclick="event.stopPropagation();buyProduct(\'' + e(x.id) + '\')">Beli sekarang</button></div></article>';
      }).join('') + '</div>';
    var sec = document.getElementById('kPromo');
    if (!sec) {
      sec = document.createElement('section'); sec.id = 'kPromo'; sec.className = 'wrap section k-sec';
      var ref = document.getElementById('fitur') || document.querySelector('.marquee');
      if (ref && ref.parentNode) ref.parentNode.insertBefore(sec, ref); else home.appendChild(sec);
    }
    if (sec.dataset.k === String(day) + pick.length && sec.firstChild) return true;
    sec.dataset.k = String(day) + pick.length; sec.innerHTML = html; return true;
  }
  (function hookPromo() { var n = 0, iv = setInterval(function () { var ok = false; try { ok = kPromo(); } catch (e) {} if (ok || ++n > 60) clearInterval(iv); }, 400); })();


  /* ---- Foto produk: bila foto asli (images/...) belum ada, pakai cover cadangan images/auto/<nama-file>.webp ---- */
  document.addEventListener('error', function (e) {
    var t = e.target; if (!t || t.tagName !== 'IMG' || t.dataset.kfb) return;
    var m = /\/?images\/(?!auto\/|p\/|banner|logo)(?:[^?#\/]+\/)*([^?#\/]+)\.(?:webp|png|jpe?g)(?:[?#].*)?$/i.exec(t.getAttribute('src') || ''); if (!m) return;
    t.dataset.kfb = '1'; e.stopPropagation(); t.src = 'images/auto/' + m[1] + '.webp';
  }, true);
  /* ---- Harga Rp 0: tagihan "sesuai tagihan" lewat admin, game belum rilis "segera hadir" ---- */
  function kProd(id) { try { var P = (typeof db !== 'undefined' && db.products) || []; for (var i = 0; i < P.length; i++) if (P[i].id === id) return P[i]; var L = (window.JK_LOCAL_DATA || {}).products || []; for (var j = 0; j < L.length; j++) if (L[j].id === id) return L[j]; } catch (e) {} return null; }
  function kFixZero() {
    document.querySelectorAll('#productGrid .card:not([data-kz])').forEach(function (c) {
      var m = /(?:buyProduct|openDetail)\('([^']+)'\)/.exec(c.getAttribute('onclick') || ''); if (!m) return;
      var p = kProd(m[1]); c.dataset.kz = '1'; if (!p || p.price > 0) return;
      var pr = c.querySelector('.price'); if (pr) pr.textContent = p.stok === 0 ? 'Segera hadir' : 'Sesuai tagihan';
      var sl = c.querySelector('.stock-label'); if (sl && p.stok === 0) { sl.textContent = 'Belum tersedia'; sl.classList.add('out'); }
      var bt = c.querySelector('.btn-primary'); if (bt) bt.textContent = p.stok === 0 ? 'Segera' : 'Via Admin';
    });
  }
  (function hookZero() {
    var n = 0, iv = setInterval(function () {
      var g = document.getElementById('productGrid');
      if (g && !g.dataset.kzObs) { g.dataset.kzObs = '1'; var t; new MutationObserver(function () { clearTimeout(t); t = setTimeout(kFixZero, 60); }).observe(g, { childList: true }); kFixZero(); }
      if (typeof window.buyProduct === 'function' && !window.buyProduct.__kz) {
        var o = window.buyProduct, f = function (id) {
          var p = kProd(id);
          if (p && !(p.price > 0)) {
            if (p.stok === 0) { try { toast('Produk ini segera hadir. Hubungi admin untuk info.'); } catch (e) {} return; }
            window.open('https://wa.me/628991232005?text=' + encodeURIComponent('Halo admin JK ADISTORE, saya mau bayar/pesan: ' + p.name + '. Mohon info nominal & cara pembayarannya.'), '_blank'); return;
          }
          return o.apply(this, arguments);
        };
        f.__kz = true; window.buyProduct = f;
      }
      if (++n > 80) clearInterval(iv);
    }, 400);
  })();
  /* ---- animasi muncul saat scroll (ringan, hanya opacity/transform) ---- */
  function kReveal() {
    if (!('IntersectionObserver' in window) || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) return;
    document.documentElement.classList.add('kJs');
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('kIn'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    function scan() { document.querySelectorAll('#home .section > h2, #home .sh-head, #home .feature-tile, #home .k-sec > *, #home .card, #home .jk-cat-card').forEach(function (el) { if (!el.dataset.kRv) { el.dataset.kRv = '1'; el.classList.add('kRv'); io.observe(el); } }); }
    setTimeout(function () { document.querySelectorAll('.kRv:not(.kIn)').forEach(function (e) { var r = e.getBoundingClientRect(); if (r.top < innerHeight * 1.2) e.classList.add('kIn'); }); }, 2500);
    scan(); var t, mo = new MutationObserver(function () { clearTimeout(t); t = setTimeout(scan, 200); }); mo.observe(document.getElementById('home') || document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', kReveal); else kReveal();
  function start() { boot(); clockGuard(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

/* Statistik beranda: sembunyikan "0 member" dan samakan rating dengan ulasan yang tampil */
(function () {
  function fix() {
    var m = document.getElementById('memberStat');
    if (m) { var c = m.closest('.stat-chip'); if (c) c.style.display = (parseInt(String(m.textContent).replace(/\D/g, ''), 10) > 0) ? '' : 'none'; }
    try {
      var rv = (window.JK_LOCAL_DATA && window.JK_LOCAL_DATA.reviews) || [], n = 0, t = 0;
      rv.forEach(function (r) { if (+r.stars > 0) { n++; t += +r.stars; } });
      if (n) {
        var chips = document.querySelectorAll('.stat-chip');
        for (var i = 0; i < chips.length; i++) {
          var sm = chips[i].querySelector('small');
          if (sm && /RATING/i.test(sm.textContent)) { var sp = chips[i].querySelector('span'), val = (t / n).toFixed(1); if (sp && sp.textContent.replace(/[^0-9.]/g, '') !== val) sp.textContent = val; }
          else if (!sm) continue;
        }
      }
    } catch (e) {}
  }
  var k = 0, iv = setInterval(function () { fix(); if (++k > 12) clearInterval(iv); }, 500);
  if (document.readyState !== 'loading') fix(); else document.addEventListener('DOMContentLoaded', fix);
})();

/* Centang biru toko: di header dan judul beranda. Klik = menuju bagian Verifikasi Keaslian Digital. */
(function () {
  var SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#1d9bf0" d="M12 1.6l2.6 1.9 3.2-.1 1 3 2.6 1.9-.9 3.1.9 3.1-2.6 1.9-1 3-3.2-.1L12 22.4l-2.6-1.9-3.2.1-1-3-2.6-1.9.9-3.1-.9-3.1 2.6-1.9 1-3 3.2.1z"/><path fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" d="M7.6 12.4l3 3 5.8-6.2"/></svg>';
  function make(cls) {
    var b = document.createElement('span');
    b.className = 'kVerif ' + cls; b.setAttribute('role', 'link'); b.tabIndex = 0;
    b.title = 'Toko terverifikasi — lihat verifikasi keaslian digital'; b.setAttribute('aria-label', b.title);
    b.innerHTML = SVG;
    function go(e) { e.preventDefault(); e.stopPropagation(); var t = document.getElementById('verifikasi'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    b.addEventListener('click', go); b.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') go(e); });
    return b;
  }
  function put() {
    var n = document.querySelector('.topbar .brand-name');
    if (n && !n.parentNode.querySelector('.kVerif')) n.parentNode.appendChild(make('kv-s'));
    var h = document.getElementById('heroTitle');
    if (h && !h.querySelector('.kVerif')) h.appendChild(make('kv-l'));
    var f = document.querySelector('footer .brand-name, .footer-brand, footer h3');
  }
  var k = 0, iv = setInterval(function () { put(); if (++k > 20) clearInterval(iv); }, 600);
  if (document.readyState !== 'loading') put(); else document.addEventListener('DOMContentLoaded', put);
})();


/* Angka statistik beranda: hitung naik sekali saja; pembaruan data berikutnya langsung ke nilai akhir (tanpa reset ke 0 / kedip) */
(function () {
  function install() {
    if (typeof window.animateStat !== 'function' || window.animateStat.__kz) return;
    var f = function (id, val) {
      var el = document.getElementById(id); if (!el) return;
      val = +val || 0;
      var tok = (el._kzTok = (el._kzTok || 0) + 1);
      if (val <= 0) { el.textContent = '0'; return; }
      var fin = val.toLocaleString('id-ID');
      if (el._kzDone) { if (el.textContent !== fin) el.textContent = fin; return; }
      el._kzDone = true;
      var cur = 0, step = Math.max(1, Math.ceil(val / 45));
      (function tick() {
        if (el._kzTok !== tok) return;
        cur += step;
        if (cur >= val) { el.textContent = fin; return; }
        el.textContent = cur.toLocaleString('id-ID');
        requestAnimationFrame(tick);
      })();
    };
    f.__kz = true; window.animateStat = f;
  }
  install();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install);
})();
