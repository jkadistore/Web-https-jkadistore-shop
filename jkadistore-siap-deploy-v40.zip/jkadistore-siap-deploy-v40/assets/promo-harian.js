/* Promo harian: kode voucher + produk diskon 30% yang berganti tiap hari (WIB). Kode & produk ditentukan server. */
(function () {
  'use strict';
  var P = window.JK_PROMO = { code: '', pct: 30, cap: 50000, picks: [], day: '', ends: 0,
    isEligible: function (id) { return !!this.code && this.picks.indexOf(String(id)) > -1; } };
  function rp(n) { return 'Rp ' + Math.round(n).toLocaleString('id-ID'); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function products() { try { return (window.JK_LOCAL_DATA && window.JK_LOCAL_DATA.products) || []; } catch (e) { return []; } }
  function find(id) { var a = products(); for (var i = 0; i < a.length; i++) if (String(a[i].id) === String(id)) return a[i]; return null; }
  function save(m) { return Math.min(Math.round(m * P.pct / 100), P.cap); }

  function render() {
    var old = document.getElementById('promoHarian'); if (old) old.remove();
    var items = P.picks.map(find).filter(Boolean);
    var shop = document.getElementById('shop'); if (!shop || !P.code || !items.length) return;
    var sec = document.createElement('section'); sec.className = 'wrap section'; sec.id = 'promoHarian';
    var cards = items.map(function (p) {
      var now = p.price - save(p.price);
      return '<button type="button" class="ph-card" data-id="' + esc(p.id) + '">' +
        '<span class="ph-badge">-' + P.pct + '%</span>' +
        '<span class="ph-img"><img loading="lazy" decoding="async" src="' + esc(p.img) + '" alt="' + esc(p.name) + '"></span>' +
        '<span class="ph-name">' + esc(p.name) + '</span>' +
        '<span class="ph-old">' + rp(p.price) + '</span><span class="ph-new">' + rp(now) + '</span></button>';
    }).join('');
    sec.innerHTML = '<div class="ph-box"><div class="ph-head"><div><div class="ph-kicker">PROMO HARI INI</div>' +
      '<h2>Diskon ' + P.pct + '% Produk Pilihan</h2><p>Berganti setiap hari. Pakai kode saat checkout, maksimal hemat ' + rp(P.cap) + ' per pesanan.</p></div>' +
      '<div class="ph-time"><span>Berakhir dalam</span><b id="phLeft">--:--:--</b></div></div>' +
      '<div class="ph-code"><span>Kode voucher hari ini</span><b id="phCode">' + esc(P.code) + '</b><button type="button" id="phCopy" class="btn btn-sm">Salin</button></div>' +
      '<div class="ph-row">' + cards + '</div></div>';
    shop.parentNode.insertBefore(sec, shop);
    sec.querySelectorAll('.ph-card').forEach(function (b) {
      b.addEventListener('click', function () { try { window.openDetail(b.getAttribute('data-id')); } catch (e) {} });
    });
    var cp = document.getElementById('phCopy');
    cp.addEventListener('click', function () {
      function ok() { cp.textContent = 'Tersalin'; setTimeout(function () { cp.textContent = 'Salin'; }, 1500); }
      try { navigator.clipboard.writeText(P.code).then(ok, ok); } catch (e) { ok(); }
    });
    tick();
  }
  var timer = 0;
  function tick() {
    var el = document.getElementById('phLeft'); if (!el) return;
    var left = Math.max(0, P.ends - Date.now()), h = Math.floor(left / 3600e3), m = Math.floor(left % 3600e3 / 60e3), s = Math.floor(left % 60e3 / 1e3);
    el.textContent = [h, m, s].map(function (x) { return String(x).padStart(2, '0'); }).join(':');
    clearTimeout(timer);
    if (left <= 0) { sessionStorage.removeItem('jk_promo'); setTimeout(load, 1500); return; }
    timer = setTimeout(tick, 1000);
  }
  function apply(j) {
    P.code = j.code; P.pct = j.pct || 30; P.cap = j.cap || 50000; P.picks = (j.picks || []).map(String); P.day = j.day; P.ends = j.ends;
    render();
  }
  function load() {
    try { var c = JSON.parse(sessionStorage.getItem('jk_promo') || 'null'); if (c && c.ends > Date.now()) { apply(c); return; } } catch (e) {}
    var ids = products().filter(function (p) { return +p.stok > 0 && +p.price >= 1000 && p.cat !== 'Akun MLBB' && (typeof window.JK_IS_GAME !== 'function' || window.JK_IS_GAME(p)); }).map(function (p) { return p.id; });
    if (!ids.length) return;
    fetch('/api/promo/picks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify({ ids: ids }) })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.success && j.code) { try { sessionStorage.setItem('jk_promo', JSON.stringify(j)); } catch (e) {} apply(j); } })
      .catch(function () {});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(load, 600); });
  else setTimeout(load, 600);
})();
