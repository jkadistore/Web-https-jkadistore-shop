/* ==================================================================
   JK ADISTORE — AUTH CORE v1
   SATU-SATUNYA pengendali login / daftar / OTP / lupa sandi / sesi /
   drawer menu. Menggantikan auth-bridge.js, session-bridge.js, otp-login.js
   (yang saling menimpa dan membuat login "mental-mental").

   Prinsip:
   1) Sumber kebenaran sesi = SERVER (cookie HttpOnly jka_sess lewat /api/auth/session).
      localStorage hanya cermin untuk UI lama (app.js) — bukan bukti login.
   2) Role OWNER hanya aktif bila server menyatakannya (window.__JK_SRV_OWNER).
      Mengedit localStorage tidak memberi akses panel owner; endpoint owner
      juga dicek ulang di server (_worker.js).
   3) Satu alur: modal #authModal (Masuk / Daftar / OTP / Lupa sandi). Tidak ada
      redirect ke halaman login terpisah. /login & /daftar hanya membuka modal ini.
   Dimuat PALING AKHIR (setelah app.js & semua modul).
   ================================================================== */
(function () {
  'use strict';

  var LEGACY_KEYS = ['jka_dv', 'jka_token', 'token', 'jka_admin', 'jka_username', 'jka_initialized', 'user'];
  var OTP_WAIT = 30;
  var state = { user: null, ready: false, next: '', pending: null, resendTimer: null };
  window.__JK_AUTH = state;
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || !e.target || !e.target.id) return;
    var m = { loginEmail: 'loginPass', loginPass: 'authLogin', regName: 'regEmail', regEmail: 'regPhone', regPhone: 'regPass', regPass: 'regPass2', regPass2: 'authRegister', otpCodeInput: 'authVerifyOtp', recEmail: 'sendRecovery' }[e.target.id];
    if (!m) return; e.preventDefault();
    if (typeof window[m] === 'function') window[m](); else { var n = document.getElementById(m); if (n) n.focus(); }
  });
  window.__JK_SRV_OWNER = false;

  /* ---------------- util ---------------- */
  function $(id) { return document.getElementById(id); }
  function say(msg) { try { toast(msg); } catch (e) { } }
  function show(id, on) { var e = $(id); if (e) e.style.display = on ? '' : 'none'; }
  function setText(id, t) { var e = $(id); if (e) e.textContent = t == null ? '' : String(t); }
  function hid(id, on) { var e = $(id); if (e) e.classList[on ? 'add' : 'remove']('hidden'); }
  function safeNext(n) { return (typeof n === 'string' && /^\/(?![\/\\])/.test(n)) ? n : ''; }
  /* api() TIDAK pernah reject: kegagalan jaringan -> {__net:true}, respons bukan JSON -> pesan jelas.
     Dengan begitu "Koneksi gagal" hanya muncul bila memang jaringan yang putus. */
  function api(path, opts) {
    opts = opts || {};
    return fetch(path, {
      method: opts.method || 'GET', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: opts.body ? JSON.stringify(opts.body) : undefined
    }).then(function (r) {
      return r.text().then(function (t) {
        var j = null; try { j = JSON.parse(t); } catch (e) { j = null; }
        if (!j || typeof j !== 'object') { j = {}; if (r.status >= 500) j.error = 'Server sedang bermasalah (kode ' + r.status + '). Coba lagi sebentar lagi.'; else if (r.status === 403 || r.status === 429) j.error = 'Permintaan ditolak (kode ' + r.status + '). Tunggu sebentar lalu coba lagi.'; }
        j.__status = r.status; return j;
      });
    }, function () {
      return { success: false, __net: true, __status: 0, error: 'Jaringan bermasalah. Periksa koneksi lalu coba lagi.' };
    });
  }
  function busy(btn, on, label) {
    if (!btn) return;
    if (on) { btn._t = btn.textContent; btn.disabled = true; btn.textContent = label || 'Memproses…'; }
    else { btn.disabled = false; if (btn._t) btn.textContent = btn._t; }
  }
  function setMsg(text, kind) {
    var m = $('authMsg'); if (!m) return;
    m.textContent = text || '';
    m.className = 'authMsg ' + (kind || '');
    m.style.display = text ? 'block' : 'none';
  }
  function saveLocal() { try { if (typeof save === 'function') save(); } catch (e) { } }
  function clearLegacy() { try { LEGACY_KEYS.forEach(function (k) { localStorage.removeItem(k); }); } catch (e) { } }

  /* ---------------- sesi: server -> UI ---------------- */
  function applySession(u) {
    state.user = (u && u.email) ? u : null;
    window.__JK_SRV_OWNER = !!(state.user && state.user.role === 'owner');
    var D = null; try { D = (typeof db !== 'undefined') ? db : null; } catch (e) { D = null; }
    if (D) {
      D.users = D.users || [];
      if (state.user) {
        var em = String(u.email).toLowerCase(), rec = null, i;
        for (i = 0; i < D.users.length; i++) { if (String(D.users[i].email || '').toLowerCase() === em) { rec = D.users[i]; break; } }
        if (!rec) {
          rec = { id: u.id || ('srv_' + Date.now()), email: u.email, name: u.name || u.email, pass: '', coins: Number(u.coins) || 0, poin: Number(u.poin) || 0, wa: u.wa || '', avatar: u.avatar || '', joined: u.joined || new Date().toISOString() };
          D.users.push(rec);
        } else {
          rec.name = u.name || rec.name;
          if (u.wa) rec.wa = u.wa;
          if (u.avatar) rec.avatar = u.avatar;
          rec.poin = Number(u.poin) || rec.poin || 0;
          rec.joined = rec.joined || u.joined || new Date().toISOString();
        }
        rec.role = u.role === 'owner' ? 'owner' : 'user';
        var isOwn = u.role === 'owner';
        D.session = {
          id: rec.id || u.id, email: rec.email, name: rec.name, pass: '',
          coins: isOwn ? 999999999 : Math.max(Number(u.coins) || 0, Number(rec.coins) || 0),
          poin: rec.poin || 0, wa: rec.wa || '', avatar: rec.avatar || '', joined: rec.joined,
          role: rec.role, _ot: u.ot || (isOwn ? 'JK2FA_srv' : 'JKUSR_srv')
        };
      } else if (D.session) {
        D.session = null;
      }
      saveLocal();
    }
    try { if (typeof renderNav === 'function') renderNav(); } catch (e) { }
    try { if (typeof renderLinkHub === 'function') renderLinkHub(); } catch (e) { }
    syncAccountUI();
    if (state.user && !state.pending) { var m = $('authModal'); if (m && m.classList.contains('show')) { try { modalHide('authModal'); } catch (e) { } } }
    try { document.dispatchEvent(new CustomEvent('jk-auth', { detail: { user: state.user } })); } catch (e) { }
  }

  function refreshSession() {
    return api('/api/auth/session').then(function (j) {
      if (j && j.success && j.user && j.user.email) applySession(j.user); else applySession(null);
      state.ready = true;
      return state.user;
    }).catch(function () { state.ready = true; return state.user; /* jaringan putus: jangan ubah status */ });
  }
  window.jkRefreshSession = refreshSession;

  /* ---------------- drawer akun (tampilan sesuai role) ---------------- */
  function syncAccountUI() {
    var u = state.user;
    show('jkAcctGuest', !u);
    show('jkAcctUser', !!u);
    show('jkAcctOut', !!u);
    if (u) {
      setText('jkAcctName', u.name || u.email);
      setText('jkAcctEmail', u.email);
      var r = $('jkAcctRole');
      if (r) { r.textContent = u.role === 'owner' ? '👑 OWNER' : 'USER'; r.className = 'jkRole ' + (u.role === 'owner' ? 'owner' : 'user'); }
      show('jkAcctAdmin', u.role === 'owner');
    }
  }
  window.jkSyncAccountUI = syncAccountUI;

  window.openNav = function () {
    var d = $('navLinks'), o = $('jkDrawerOverlay'); if (!d) return;
    syncAccountUI();
    d.classList.add('open'); if (o) o.classList.add('open');
    document.body.style.overflow = 'hidden';
  };
  window.closeNav = function () {
    var d = $('navLinks'), o = $('jkDrawerOverlay');
    if (d) d.classList.remove('open'); if (o) o.classList.remove('open');
    document.body.style.overflow = '';
  };
  window.toggleNav = function () { var d = $('navLinks'); if (d && d.classList.contains('open')) window.closeNav(); else window.openNav(); };
  window.jkNav = function (id) { window.closeNav(); var e = $(id); if (e) e.scrollIntoView({ behavior: 'smooth', block: 'start' }); };
  window.smoothTo = window.jkNav;
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') window.closeNav(); });

  window.jkAcct = function (act) {
    window.closeNav();
    if (act === 'login') return window.openAuth('login');
    if (act === 'register') return window.openAuth('register');
    if (act === 'profile') { location.href = '/profile'; return; }
    if (act === 'orders') { location.href = '/profile#pesanan'; return; }
    if (act === 'topup') { if (typeof openTopup === 'function') openTopup(); return; }
    if (act === 'admin') {
      if (window.__JK_SRV_OWNER && typeof adminOpen === 'function') adminOpen(); else say('🔒 Akses khusus owner');
      return;
    }
    if (act === 'logout') return window.jkLogout();
  };
  window.jkAccountBtn = function () { if (state.user) location.href = '/profile'; else window.openAuth('login'); };

  /* ---------------- modal: tab Masuk / Daftar ---------------- */
  var TITLES = {
    login: ['Selamat datang!', 'Masukkan email dan kata sandi Anda untuk masuk ke akun Anda.'],
    register: ['Daftar', 'Masukkan email dan kata sandi untuk membuat akun baru.'],
    otp: ['Verifikasi', 'Masukkan kode OTP yang kami kirim ke email Anda.'],
    recovery: ['Lupa Password', 'Masukkan email terdaftar untuk menerima kode pemulihan.']
  };
  function view(name) {
    ['login', 'register', 'otp', 'recovery'].forEach(function (v) { hid(v + 'Area', v !== name); });
    setText('authTitle', TITLES[name][0]); setText('authSub', TITLES[name][1]);
  }
  function showForms(tab) { view(tab === 'register' ? 'register' : 'login'); }
  window.authSwitch = function (tab) {
    tab = tab === 'register' ? 'register' : 'login';
    clearInterval(state.resendTimer); state.pending = null;
    setMsg('');
    showForms(tab);
  };
  window.openAuth = function (tab) {
    if (state.user) { say('Kamu sudah masuk 👋'); return; }
    window.authSwitch(tab);
    try { modalShow('authModal'); } catch (e) { }
    setTimeout(function () { var f = $(tab === 'register' ? 'regName' : 'loginEmail'); if (f && f.focus) f.focus(); }, 80);
  };

  /* ---------------- OTP ---------------- */
  function showOtp(email, mode) {
    state.pending = state.pending || {};
    state.pending.email = email; state.pending.mode = mode;
    view('otp');
    setText('authSub', 'Kode 6 digit dikirim ke ' + email + '. Berlaku 5 menit.');
    var inp = $('otpCodeInput'); if (inp) { inp.value = ''; setTimeout(function () { inp.focus(); }, 80); }
    setMsg('Kode OTP terkirim. Cek inbox / folder spam.', 'ok');
    startResend(OTP_WAIT);
  }
  function startResend(sec) {
    var b = $('otpResendBtn'); if (!b) return;
    clearInterval(state.resendTimer);
    var left = sec;
    function tick() {
      if (left > 0) { b.disabled = true; b.textContent = 'Kirim ulang kode (' + left + 'd)'; left--; }
      else { b.disabled = false; b.textContent = 'Kirim ulang kode'; clearInterval(state.resendTimer); }
    }
    tick(); state.resendTimer = setInterval(tick, 1000);
  }
  window.authBackFromOtp = function () {
    var mode = (state.pending && state.pending.mode) || 'login';
    clearInterval(state.resendTimer); state.pending = null; setMsg('');
    showForms(mode);
  };
  window.authResendOtp = function () {
    var p = state.pending; if (!p) return window.authBackFromOtp();
    var b = $('otpResendBtn'); busy(b, true, 'Mengirim…');
    var req = p.mode === 'register'
      ? api('/api/auth/register', { method: 'POST', body: { name: p.name, email: p.email, wa: p.wa, password: p.password, confirm: p.confirm, next: state.next || '/' } })
      : api('/api/auth/login', { method: 'POST', body: { email: p.email, password: p.password } });
    req.then(function (j) {
      busy(b, false);
      if (j.success && j.otp_required) { setMsg('Kode baru terkirim.', 'ok'); startResend(OTP_WAIT); }
      else { setMsg(j.error || 'Gagal mengirim ulang kode', 'err'); startResend(Math.max(Number(j.retry) || 0, 5)); }
    }).catch(function () { busy(b, false); setMsg('Terjadi kesalahan di aplikasi. Muat ulang halaman lalu coba lagi.', 'err'); startResend(5); });
  };
  function finishLogin(user, mode) {
    var wasOwner = user.role === 'owner';
    clearInterval(state.resendTimer); state.pending = null; setMsg('');
    applySession(user);
    try { modalHide('authModal'); } catch (e) { }
    say(mode === 'register' ? '🎉 Akun aktif! Selamat datang, ' + (user.name || '') : (wasOwner ? '👑 Selamat datang, Owner' : '👋 Halo, ' + (user.name || '')));
    var nx = safeNext(state.next);
    if (nx && nx !== location.pathname + location.search) { setTimeout(function () { location.href = nx; }, 350); return; }
    if (wasOwner) setTimeout(function () { location.reload(); }, 500);   // owner: muat ulang agar sinkron data toko
  }
  window.authVerifyOtp = function () {
    var p = state.pending; if (!p) return window.authBackFromOtp();
    var code = (($('otpCodeInput') || {}).value || '').replace(/\D/g, '');
    if (code.length !== 6) { setMsg('Masukkan 6 digit kode OTP', 'err'); return; }
    var b = $('otpVerifyBtn'); busy(b, true, 'Memverifikasi…');
    api('/api/otp/verify', { method: 'POST', body: { email: p.email, code: code } }).then(function (j) {
      if (j && j.success && j.user) { busy(b, false); finishLogin(j.user, p.mode); return; }
      if (j && j.__net) {
        /* respons bisa saja hilang padahal server sudah menerima kode -> cek apakah sesi sudah terbentuk */
        return refreshSession().then(function (u) {
          busy(b, false);
          if (u && String(u.email).toLowerCase() === String(p.email).toLowerCase()) { finishLogin(u, p.mode); return; }
          setMsg(j.error + ' (Kode OTP tetap berlaku — tekan Verifikasi lagi. Kalau berkali-kali gagal, tekan Kembali lalu Masuk ulang.)', 'err');
        });
      }
      busy(b, false);
      setMsg((j && j.error) || 'Kode salah atau kedaluwarsa', 'err');
    });
  };


  /* ---------------- verifikasi robot ---------------- */
  var BOTS = {};
  function botLoad(key) {
    var box = BOTS[key]; if (!box) return;
    box.innerHTML = '<span class="kBotQ">Memuat verifikasi…</span>';
    api('/api/captcha').then(function (j) {
      if (j.mode === 'turnstile') {
        box.dataset.mode = 'ts'; box.innerHTML = '<div class="kBotTs"></div>';
        var go = function () { try { box._wid = window.turnstile.render(box.firstChild, { sitekey: j.sitekey, theme: 'dark', callback: function (t) { box._tok = t; }, 'expired-callback': function () { box._tok = ''; }, 'error-callback': function () { box._tok = ''; } }); } catch (e) { } };
        if (window.turnstile) go(); else { var sc = document.createElement('script'); sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; sc.async = true; sc.onload = go; document.head.appendChild(sc); }
      } else if (j.mode === 'math') {
        box.dataset.mode = 'math'; box._tok = j.token;
        box.innerHTML = '<span class="kBotIc">🤖</span><span class="kBotQ">Verifikasi kamu bukan robot: <b>' + j.q + '</b></span><input class="kBotA" inputmode="numeric" autocomplete="off" maxlength="3" placeholder="Jawab"><button type="button" class="kBotR" aria-label="Soal baru">↻</button>';
        box.querySelector('.kBotR').onclick = function () { botLoad(key); };
      } else { box.innerHTML = '<span class="kBotQ">Verifikasi gagal dimuat. <a href="#" class="kLink">Coba lagi</a></span>'; var a = box.querySelector('a'); if (a) a.onclick = function (e) { e.preventDefault(); botLoad(key); }; }
    });
  }
  function botMount(key, btn) {
    if (!btn || BOTS[key]) return;
    var box = document.createElement('div'); box.className = 'kBot'; BOTS[key] = box; btn.parentNode.insertBefore(box, btn); botLoad(key);
  }
  function botData(key) {
    var box = BOTS[key]; if (!box) return {};
    if (box.dataset.mode === 'ts') return { cf_token: box._tok || '' };
    var a = box.querySelector('.kBotA'); return { cap_token: box._tok || '', cap_answer: a ? a.value.trim() : '' };
  }
  function botReady(key) {
    var box = BOTS[key]; if (!box) return true;
    if (box.dataset.mode === 'ts') return !!box._tok;
    var a = box.querySelector('.kBotA'); return !!(a && a.value.trim());
  }
  function botReset(key) { var b = BOTS[key]; if (b && b.dataset.mode === 'ts' && window.turnstile && b._wid != null) { b._tok = ''; try { window.turnstile.reset(b._wid); } catch (e) { } } else botLoad(key); }
  function botInit() {
    botMount('login', $('loginSubmit')); botMount('reg', $('registerSubmit'));
    botMount('rec', document.querySelector('button[onclick="sendRecovery()"]'));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', botInit); else botInit();

  /* ---------------- login & daftar ---------------- */
  window.authLogin = function () {
    var email = (($('loginEmail') || {}).value || '').trim().toLowerCase();
    var pass = ($('loginPass') || {}).value || '';
    if (!email || !pass) { setMsg('Isi email & kata sandi dulu', 'err'); return; }
    if (!botReady('login')) { setMsg('Selesaikan verifikasi robot dulu', 'err'); return; }
    var b = $('loginSubmit'); busy(b, true);
    var lbd = Object.assign({ email: email, password: pass }, botData('login'));
    api('/api/auth/login', { method: 'POST', body: lbd }).then(function (j) {
      busy(b, false); botReset('login');
      if (j.success && j.otp_required) { state.pending = { mode: 'login', email: email, password: pass }; showOtp(email, 'login'); if (j.unverified) setMsg('Email kamu belum diverifikasi. Kami kirim kode verifikasi — masukkan untuk mengaktifkan akun.', 'ok'); return; }
      setMsg(j.error || 'Login gagal', 'err');
    }).catch(function () { busy(b, false); setMsg('Terjadi kesalahan di aplikasi. Muat ulang halaman lalu coba lagi.', 'err'); });
  };
  window.authRegister = function () {
    var name = (($('regName') || {}).value || '').trim();
    var email = (($('regEmail') || {}).value || '').trim().toLowerCase();
    var phone = (($('regPhone') || {}).value || '').replace(/[^0-9]/g, '');
    var pass = ($('regPass') || {}).value || '', pass2 = ($('regPass2') || {}).value || '';
    if (phone.indexOf('0') === 0) phone = '62' + phone.slice(1);
    if (name.length < 2) { setMsg('Nama minimal 2 karakter', 'err'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setMsg('Format email tidak valid', 'err'); return; }
    if (!/^628\d{7,12}$/.test(phone)) { setMsg('Nomor telepon tidak valid (contoh: 628123456789)', 'err'); return; }
    if (pass.length < 6) { setMsg('Kata sandi minimal 6 karakter', 'err'); return; }
    if (pass !== pass2) { setMsg('Konfirmasi kata sandi tidak sama', 'err'); return; }
    if (!($('regTerms') || {}).checked) { setMsg('Centang persetujuan syarat dan ketentuan dulu', 'err'); return; }
    if (!botReady('reg')) { setMsg('Selesaikan verifikasi robot dulu', 'err'); return; }
    var b = $('registerSubmit'); busy(b, true);
    api('/api/auth/register', { method: 'POST', body: Object.assign({ name: name, email: email, wa: phone, password: pass, confirm: pass2, next: state.next || '/' }, botData('reg')) }).then(function (j) {
      busy(b, false); botReset('reg');
      if (j.success && j.otp_required) { state.pending = { mode: 'register', email: email, password: pass, confirm: pass2, name: name, wa: phone }; showOtp(email, 'register'); return; }
      setMsg(j.error || 'Pendaftaran gagal', 'err');
    }).catch(function () { busy(b, false); setMsg('Terjadi kesalahan di aplikasi. Muat ulang halaman lalu coba lagi.', 'err'); });
  };
  window.authTerms = function () { try { modalHide('authModal'); } catch (e) { } var f = $('kFaq'); if (f) f.scrollIntoView({ behavior: 'smooth' }); };
  window.kEye = function (id, btn) { var i = $(id); if (!i) return; var show = i.type === 'password'; i.type = show ? 'text' : 'password'; if (btn) btn.classList.toggle('on', show); };
  /* kirim ulang kode daftar: ikutkan telepon & konfirmasi */
  /* Google: deteksi dulu apakah endpoint OAuth server tersedia (tidak menebak buta) */
  window.authGoogle = function () {
    var b = $('googleBtn'); busy(b, true, 'Menghubungkan…');
    var nx = encodeURIComponent(safeNext(state.next) || '/'), paths = ['/api/auth/google', '/api/auth/oauth/google', '/api/auth/google/login'], i = 0;
    function next() {
      if (i >= paths.length) { busy(b, false); setMsg('Login Google belum aktif di server ini. Silakan masuk dengan email & sandi.', 'err'); return; }
      var p = paths[i++];
      fetch(p + '?next=' + nx, { method: 'GET', redirect: 'manual', credentials: 'same-origin' }).then(function (r) {
        if (r.type === 'opaqueredirect' || (r.status >= 300 && r.status < 400)) { location.href = p + '?next=' + nx; } else next();
      }, function () { next(); });
    }
    next();
  };

  window.authDiscord = function () {
    var b = $('discordBtn'); busy(b, true, 'Menghubungkan…');
    var nx = encodeURIComponent(safeNext(state.next) || '/');
    fetch('/api/auth/discord?next=' + nx, { method: 'GET', redirect: 'manual', credentials: 'same-origin' }).then(function (r) {
      if (r.type === 'opaqueredirect' || (r.status >= 300 && r.status < 400)) { location.href = '/api/auth/discord?next=' + nx; return; }
      busy(b, false);
      return r.json().catch(function () { return {}; }).then(function (j) { setMsg((j && j.error) || 'Login Discord belum aktif di server ini. Silakan masuk dengan email & sandi.', 'err'); });
    }).catch(function () { busy(b, false); setMsg('Koneksi bermasalah. Coba lagi.', 'err'); });
  };

  /* ---------------- lupa sandi ---------------- */
  window.showRecovery = function () { setMsg(''); view('recovery'); var e = $('recEmail'), l = $('loginEmail'); if (e && l && !e.value) e.value = l.value; };
  window.sendRecovery = function () {
    var email = (($('recEmail') || {}).value || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setMsg('Isi email terdaftar yang valid', 'err'); return; }
    if (!botReady('rec')) { setMsg('Selesaikan verifikasi robot dulu', 'err'); return; }
    api('/api/auth/forgot', { method: 'POST', body: Object.assign({ email: email }, botData('rec')) }).then(function (j) {
      botReset('rec');
      if (j.success) { hid('recCodeWrap', false); setMsg('Kode pemulihan terkirim ke email.', 'ok'); }
      else setMsg(j.error || 'Gagal mengirim kode', 'err');
    }).catch(function () { setMsg('Terjadi kesalahan di aplikasi. Muat ulang halaman lalu coba lagi.', 'err'); });
  };
  window.resetPassword = function () {
    var email = (($('recEmail') || {}).value || '').trim().toLowerCase();
    var code = (($('recCode') || {}).value || '').replace(/\D/g, '');
    var pass = ($('recNewPass') || {}).value || '';
    if (code.length !== 6) { setMsg('Masukkan 6 digit kode', 'err'); return; }
    if (pass.length < 6) { setMsg('Sandi baru minimal 6 karakter', 'err'); return; }
    api('/api/auth/forgot/verify', { method: 'POST', body: { email: email, code: code, password: pass } }).then(function (j) {
      if (j.success) {
        say('✅ Sandi diganti. Silakan masuk.');
        var le = $('loginEmail'); if (le) le.value = email; var lp = $('loginPass'); if (lp) lp.value = '';
        ['recCode', 'recNewPass'].forEach(function (id) { var x = $(id); if (x) x.value = ''; });
        hid('recCodeWrap', true); window.authSwitch('login');
        setMsg('Sandi berhasil diganti. Masuk dengan sandi baru.', 'ok');
      } else setMsg(j.error || 'Gagal reset sandi', 'err');
    }).catch(function () { setMsg('Terjadi kesalahan di aplikasi. Muat ulang halaman lalu coba lagi.', 'err'); });
  };

  /* ---------------- keluar ---------------- */
  window.jkLogout = function () {
    var done = false;
    function fin() {
      if (done) return; done = true;
      clearLegacy();
      try { if (typeof db !== 'undefined' && db) { db.session = null; saveLocal(); } } catch (e) { }
      window.__JK_SRV_OWNER = false;
      location.replace('/');
    }
    api('/api/auth/logout', { method: 'POST' }).then(fin, fin);
    setTimeout(fin, 1500);
  };
  window.logout = window.authLogout = window.jkLogout;
  window.openProfile = function () { location.href = '/profile'; };
  window.showUserMenu = function () { window.openNav(); };

  /* ---------------- guard: pembelian & panel owner ---------------- */
  try {
    if (typeof window.buyProduct === 'function') {
      var _buy = window.buyProduct;
      window.buyProduct = function () {
        if (!state.user) { say('Masuk dulu untuk memesan'); window.openAuth('login'); return; }
        return _buy.apply(this, arguments);
      };
    }
  } catch (e) { }
  try {
    var _ms = window.modalShow;
    if (typeof _ms === 'function') {
      window.modalShow = function (id) {
        if (id === 'adminModal' && !window.__JK_SRV_OWNER) { say('🔒 Akses khusus owner'); return; }
        return _ms.apply(this, arguments);
      };
    }
  } catch (e) { }
  /* owner HANYA dari server: fallback cek email/sandi lokal dimatikan */
  window.__JK_CHK_E = function () { return false; };
  window.__JK_CHK_P = function () { return false; };

  /* ---------------- boot ---------------- */
  function bootRoute() {
    var q, a = '';
    try { q = new URLSearchParams(location.search); a = q.get('auth') || ''; state.next = safeNext(q.get('next') || ''); state.authErr = (q.get('auth_error') || '').slice(0, 160); } catch (e) { }
    if (!a) { var pth = location.pathname.replace(/\/+$/, '').toLowerCase(); if (pth === '/login') a = 'login'; else if (pth === '/daftar' || pth === '/register') a = 'register'; }
    if (a === 'login' || a === 'register') {
      try { history.replaceState(null, '', (/^\/(login|daftar|register)\/?$/i.test(location.pathname) ? '/' : location.pathname) + location.hash); } catch (e) { }
      return a;
    }
    return '';
  }
  var wantAuth = bootRoute();

  function boot() {
    syncAccountUI();
    refreshSession().then(function (u) {
      if (wantAuth) {
        if (u) { var nx = safeNext(state.next); if (nx && nx !== '/' && nx !== location.pathname) location.replace(nx); }
        else { window.openAuth(wantAuth); if (state.authErr) { setTimeout(function () { setMsg(state.authErr, 'err'); state.authErr = ''; }, 60); } }
        wantAuth = '';
      }
      try {
        if (u && u.role === 'owner' && /[?&]admin=1/.test(location.search)) { try { history.replaceState(null, '', location.pathname); } catch (e) { } setTimeout(function () { if (typeof adminOpen === 'function') adminOpen(); }, 400); }
        if (u && localStorage.getItem('jk_open_topup') === '1') {
          localStorage.removeItem('jk_open_topup');
          setTimeout(function () { try { if (typeof openTopup === 'function') openTopup(); } catch (e) { } }, 300);
        }
      } catch (e) { }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('pageshow', function (e) { if (e.persisted) refreshSession(); });
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && state.ready) refreshSession(); });
})();
