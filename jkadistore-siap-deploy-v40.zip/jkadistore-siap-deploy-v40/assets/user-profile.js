/* ==================================================================
   JK ADISTORE — USER PROFILE MODULE (halaman profil mobile user)
   Baru: TIDAK mengubah app.js / owner-panel.js / tombol lama.
   Halaman: profile.html  (ungu gelap + putih + aksen kuning)
   Data  : localStorage jka_db_v3 (toko utama) + foto via
           app.jkadistore.shop (foto → URL) bila tersedia.
   ================================================================== */
(function () {
  'use strict';

  /* ---------- helper ---------- */
  function escU(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function $(id) { return document.getElementById(id); }
  function toastU(msg) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:18px;z-index:999999;' +
      'background:#241848f2;color:#fff;font:600 12.5px system-ui,sans-serif;padding:9px 16px;' +
      'border-radius:999px;border:1px solid #FFD70088;box-shadow:0 6px 24px rgba(0,0,0,.45);max-width:88vw';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function getDB() { try { return JSON.parse(localStorage.getItem('jka_db_v3') || '{}'); } catch (e) { return {}; } }
  function setDB(d) { localStorage.setItem('jka_db_v3', JSON.stringify(d)); }
  function saveDB() { try { if (typeof save === 'function') save(); } catch (e) { } }

  function maskEmail(e) {
    e = String(e || '');
    var at = e.indexOf('@');
    if (at <= 1) return e;
    return e.slice(0, Math.min(4, at)) + '***' + e.slice(at);
  }
  function fmtRp(n) {
    n = Number(n || 0);
    return 'Rp ' + n.toLocaleString('id-ID');
  }
  function fmtJoin(iso) {
    try {
      var d = iso ? new Date(iso) : new Date();
      if (isNaN(d)) return 'Baru saja';
      return 'Sejak ' + d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: '2-digit' });
    } catch (e) { return '-'; }
  }
  function initials(name) {
    var p = String(name || 'U').trim().split(/\s+/);
    return ((p[0] || 'U')[0] + (p.length > 1 ? (p[1][0] || '') : '')).toUpperCase();
  }
  function avatarFallback(name, size) {
    try {
      var c = document.createElement('canvas');
      var s = size || 96;
      c.width = c.height = s;
      var x = c.getContext && c.getContext('2d');
      if (!x) return 'data:image/svg+xml;utf8,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="' + s + '" height="' + s + '"><rect width="100%" height="100%" fill="#3A2A7E"/><text x="50%" y="54%" text-anchor="middle" dy=".35em" fill="#FFD700" font-family="system-ui" font-weight="900" font-size="' + Math.floor(s / 2.6) + '">' + initials(name) + '</text></svg>'
      );
      x.fillStyle = '#3A2A7E';
      x.fillRect(0, 0, s, s);
      x.fillStyle = '#FFD700';
      x.font = '900 ' + Math.floor(s / 2.6) + 'px system-ui,sans-serif';
      x.textAlign = 'center';
      x.textBaseline = 'middle';
      x.fillText(initials(name), s / 2, s / 2 + 2);
      return c.toDataURL('image/png');
    } catch (e) {
      return 'data:image/svg+xml;utf8,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="100%" height="100%" fill="#3A2A7E"/><text x="50%" y="54%" text-anchor="middle" dy=".35em" fill="#FFD700" font-family="system-ui" font-weight="900" font-size="36">U</text></svg>'
      );
    }
  }

  /* ---------- data user ---------- */
  function currentUser() {
    var d = getDB();
    var s = d.session;
    if (!s || !s.email) return null;
    // gabung dengan data user terdaftar (pass/poin/joined dsb.)
    var rec = (d.users || []).filter(function (u) { return (u.email || '').toLowerCase() === (s.email || '').toLowerCase(); })[0];
    return { session: s, rec: rec || { email: s.email, name: s.name || s.email, coins: s.coins || 0 } };
  }

  /* ---------- JEMBATAN OAuth (BARU - mencegah loop redirect) ----------
     Pengguna yang masuk lewat OAuth (Google/GitHub/Discord via /login) punya
     sesi SERVER (cookie) tetapi belum tentu punya sesi LOKAL (jka_db_v3).
     Bila sesi lokal kosong: tanya /api/auth/session -> bila valid, buatkan
     sesi lokal + data user minimal, lalu profil tetap bisa dibuka. */
  function tryServerSession() {
    return fetch('/api/auth/session', { credentials: 'same-origin' })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (j) {
        if (!j || !j.success || !j.user || !j.user.email) throw new Error('tanpa user');
        var u = j.user;
        var d = getDB();
        var rec = (d.users || []).filter(function (x) { return (x.email || '').toLowerCase() === (u.email || '').toLowerCase(); })[0];
        if (!rec) {
          rec = { email: u.email, name: u.name || u.email, coins: Number(u.coins) || 0, wa: u.wa || '', avatar: u.avatar || '', joined: u.joined || new Date().toISOString(), id: u.id || ('srv_' + Date.now()), role: u.role || 'user', poin: Number(u.poin) || 0 };
          d.users = d.users || [];
          d.users.push(rec);
        } else {
          /* sinkronkan data server → lokal (saldo/poin/foto selalu ambil yang terbaru) */
          rec.name = rec.name || u.name || u.email;
          rec.wa = u.wa != null ? u.wa : (rec.wa || '');
          if (u.avatar) rec.avatar = u.avatar;
          if (u.joined) rec.joined = rec.joined || u.joined;
          if (u.poin != null && !rec.poin) rec.poin = Number(u.poin) || 0;
        }
        /* saldo: pertahankan yang paling besar (topup lokal vs server) */
        var coins = Math.max(Number(rec.coins) || 0, Number(u.coins) || 0);
        rec.coins = coins;
        d.session = { email: u.email, name: u.name || rec.name || u.email, coins: coins, id: rec.id, joined: rec.joined, avatar: rec.avatar || u.avatar || '', role: u.role || 'user' };
        setDB(d);
        return true;
      })
      .catch(function () { return false; });
  }

  /* ---------- render profil ---------- */
  var FOTO_UPLOAD_URL = 'https://app.jkadistore.shop'; // foto → URL (opsional)

  var _bridgeTried = false; // guard: cegah loop renderProfile <-> tryServerSession
  function renderProfile() {
    var cu = currentUser();
    if (!cu) { // coba jembatan OAuth dulu (BARU - cegah loop redirect)
      if (_bridgeTried) { location.replace('/?auth=login&next=%2Fprofile'); return; }
      _bridgeTried = true;
      tryServerSession().then(function (ok) {
        if (ok) renderProfile(); else location.replace('/?auth=login&next=%2Fprofile');
      });
      return;
    }
    var s = cu.session, rec = cu.rec;
    var orders = (getDB().orders || []).filter(function (o) { return (o.email || '').toLowerCase() === (s.email || '').toLowerCase(); });
    var purchases = orders.filter(function (o) { return o.type !== 'topup'; });
    var done = purchases.filter(function (o) { return /berhasil|selesai|sukses|lunas/i.test(String(o.status || '')); });
    var spent = purchases.reduce(function (a, o) { return a + (Number(o.price) || 0); }, 0);
    var poin = Number(rec.poin != null ? rec.poin : (rec.points != null ? rec.points : Math.floor(spent / 100)));
    var foto = rec.avatar || s.avatar || '';

    var IC = {
      list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M9 8h6M9 12h6M9 16h3"/></svg>',
      wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3"/><rect x="3" y="7" width="18" height="13" rx="2.5"/><circle cx="16.5" cy="13.5" r="1.2" fill="currentColor"/></svg>',
      user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/></svg>',
      lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
      search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
      out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 8l-4 4 4 4M6 12h10"/></svg>',
      crown: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/></svg>',
      pen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/></svg>',
      chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>',
      plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
    };
    function item(ic, t, sub, act, cls) {
      return '<button class="pf-item ' + (cls || '') + '" onclick="' + act + '"><span class="pf-ic">' + IC[ic] + '</span><span class="pf-tx"><b>' + t + '</b>' + (sub ? '<small>' + sub + '</small>' : '') + '</span><span class="pf-ch">' + IC.chev + '</span></button>';
    }
    var isOwner = s.role === 'owner';
    var level = poin >= 500 ? 'Sultan' : poin >= 150 ? 'Gold' : poin >= 30 ? 'Silver' : 'Member';
    var html = ''
      + '<section class="pf-hero">'
      + '<div class="pf-cover"><i></i><i></i><i></i></div>'
      + '<div class="pf-who">'
      + '<div class="pf-av"><img id="upFoto" src="' + escU(foto || avatarFallback(s.name || s.email, 96)) + '" alt="Foto profil"></div>'
      + '<button class="pf-edit" onclick="upEditProfile()" aria-label="Edit profil">' + IC.pen + '</button>'
      + '</div>'
      + '<div class="pf-meta">'
      + '<h1 class="pf-name">' + escU(s.name || rec.name || '-') + (isOwner ? '<span class="pf-badge own">' + IC.crown + 'Owner</span>' : '<span class="pf-badge">' + level + '</span>') + '</h1>'
      + '<p class="pf-mail">' + escU(maskEmail(s.email)) + '</p>'
      + '<p class="pf-since">' + escU(fmtJoin(rec.joined || rec.createdAt || s.joined)) + (rec.wa || rec.phone ? ' &middot; ' + escU(rec.wa || rec.phone) : '') + '</p>'
      + '</div>'
      + '</section>'

      + '<section class="pf-stats">'
      + '<div class="pf-st pf-bal"><span>Saldo</span><b>' + fmtRp(s.coins != null ? s.coins : rec.coins) + '</b><button onclick="upGoTopup()">' + IC.plus + 'Top Up</button></div>'
      + '<div class="pf-st"><span>Pesanan</span><b>' + purchases.length + '</b><small>' + done.length + ' selesai</small></div>'
      + '<div class="pf-st"><span>Poin</span><b>' + poin + '</b><small>' + fmtRp(spent) + ' belanja</small></div>'
      + '</section>'

      + (isOwner ? '<button class="pf-owner" onclick="location.href=\'/?admin=1\'">' + IC.crown + '<span>Buka Panel Owner</span>' + IC.chev + '</button>' : '')

      + '<h2 class="pf-h">Aktivitas</h2>'
      + '<div class="pf-group">'
      + item('list', 'Riwayat Pesanan', 'Semua pembelian akun ini', 'upOrders()')
      + item('search', 'Cek Transaksi', 'Lacak dengan nomor invoice', "location.href='/cek-transaksi'")
      + item('wallet', 'Top Up Saldo', 'Isi saldo untuk belanja lebih cepat', 'upGoTopup()')
      + '</div>'

      + '<h2 class="pf-h">Akun</h2>'
      + '<div class="pf-group">'
      + item('user', 'Edit Profil', 'Nama, nomor WhatsApp, dan foto', 'upEditProfile()')
      + item('lock', 'Ubah Kata Sandi', 'Ganti sandi secara berkala', 'upChangePass()')
      + '</div>'

      + '<button class="pf-out" onclick="upLogout()">' + IC.out + 'Keluar dari akun</button>'
      + '<p class="pf-foot">JK ADISTORE &middot; Akun kamu terlindungi</p>';

    $('upBody').innerHTML = html;
  }

  function upRow(icon, label, btn, extra) {
    var name = String(icon);
    var val = String(label);
    var ic = name.split(' ').slice(0, 1).join(' ');
    var nm = name.split(' ').slice(1).join(' ');
    return '<div class="up-row' + (extra ? ' ' + extra : '') + '">'
      + '<span class="up-k">' + ic + ' <b>' + escU(nm) + '</b></span>'
      + '<span class="up-v">' + val + '</span>' + btn + '</div>';
  }

  /* ---------- modal kecil (di dalam profile.html) ---------- */
  function smallModal(title, bodyHTML, onOk, okLabel, danger, cancelLabel) {
    var wrap = document.createElement('div');
    wrap.className = 'up-modal';
    wrap.innerHTML = '<div class="up-modal-box"><div class="up-grab"></div>'
      + '<div class="up-modal-title">' + title + '</div>'
      + bodyHTML
      + '<div class="up-modal-acts">'
      + '<button class="up-btn" id="upMCancel">' + (cancelLabel || 'BATAL') + '</button>'
      + '<button class="up-btn ' + (danger ? 'up-red' : 'up-gold-b') + '" id="upMOk">' + (okLabel || 'SIMPAN') + '</button>'
      + '</div></div>';
    document.body.appendChild(wrap);
    wrap.querySelector('#upMCancel').onclick = function () { wrap.remove(); };
    wrap.addEventListener('mousedown', function (e) { if (e.target === wrap) wrap.remove(); });
    wrap.querySelector('#upMOk').onclick = function () { if (onOk(wrap)) wrap.remove(); };
    return wrap;
  }

  /* ---------- 1) RIWAYAT PESANAN ---------- */
  window.upOrders = function () {
    var LBL = { menunggu: 'Menunggu', diproses: 'Diproses', berhasil: 'Berhasil', gagal: 'Gagal', dibatalkan: 'Dibatalkan' };
    var wrap = smallModal('Riwayat Pesanan', '<div class="up-list" id="upOrdBody"><div class="up-empty">Memuat…</div></div>', function () { return true; }, 'TUTUP'); wrap.querySelector('#upMCancel').style.display = 'none';
    fetch('/api/orders/mine', { credentials: 'same-origin' }).then(function (r) { return r.json().catch(function () { return {}; }); }).then(function (j) {
      var el = document.getElementById('upOrdBody'); if (!el) return;
      if (!j || !j.success) { el.innerHTML = '<div class="up-empty">' + escU((j && j.error) || 'Gagal memuat riwayat.') + '</div>'; return; }
      if (!j.orders.length) { el.innerHTML = '<div class="up-empty"><b>Belum ada pesanan</b><br>Pesanan kamu akan muncul di sini.</div>'; return; }
      el.innerHTML = j.orders.map(function (o) {
        var ok = o.status === 'berhasil';
        return '<a class="up-ord" href="/cek-transaksi?inv=' + encodeURIComponent(o.invoice) + '">'
          + '<span class="up-ord-l"><b>' + escU(o.produk) + '</b><small>' + escU(o.paket) + '</small><small class="up-inv">' + escU(o.invoice) + '</small></span>'
          + '<span class="up-ord-r"><b>' + fmtRp(o.total) + '</b><em class="st-' + escU(o.status) + '">' + escU(LBL[o.status] || o.status) + '</em></span></a>';
      }).join('');
    }).catch(function () { var el = document.getElementById('upOrdBody'); if (el) el.innerHTML = '<div class="up-empty">Koneksi bermasalah.</div>'; });
  };

  /* ---------- 2) EDIT PROFIL & GANTI FOTO ---------- */
  window.upEditProfile = function () {
    var cu = currentUser();
    var s = cu.session, rec = cu.rec;
    var body = '<div class="up-form">'
      + '<div class="up-avwrap"><img id="upEditFoto" src="' + escU(rec.avatar || s.avatar || avatarFallback(s.name, 96)) + '" class="up-foto-edit" alt="Foto"><span class="up-cam"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></span></div>'
      + '<input type="file" id="upFotoFile" accept="image/*" style="display:none">'
      + '<div class="up-form-note" style="text-align:center">Ketuk foto untuk mengganti. Otomatis dipotong persegi &amp; dioptimalkan 512&times;512 (HD).</div>'
      + '<label class="up-lbl" for="upName">Nama lengkap</label><input class="up-input" id="upName" placeholder="Nama kamu" value="' + escU(s.name || rec.name || '') + '" maxlength="40">'
      + '<label class="up-lbl" for="upWA">Nomor WhatsApp</label><input class="up-input" id="upWA" placeholder="08123456789" value="' + escU(rec.wa || rec.phone || '') + '" inputmode="tel" maxlength="18">'
      + '</div>';
    smallModal('Edit Profil', body, function (w) {
      var name = (w.querySelector('#upName') || {}).value || '';
      var wa = (w.querySelector('#upWA') || {}).value || '';
      if (!name.trim()) { toastU('Nama tidak boleh kosong.'); return false; }
      var btn = w.querySelector('#upMOk');
      if (btn) { btn.disabled = true; btn.textContent = 'MENYIMPAN…'; }
      var finish = function (avatarUrl) {
        fetch('/api/auth/profile', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: name.trim(), wa: wa.trim(), avatar: avatarUrl })
        }).then(function (r) { return r.json().catch(function () { return {}; }); }).then(function (res) {
          if (res && res.success) {
            /* sinkron data lokal lalu render ulang */
            var d = getDB();
            var idx = (d.users || []).findIndex(function (u) { return (u.email || '').toLowerCase() === (s.email || '').toLowerCase(); });
            if (idx >= 0) {
              d.users[idx].name = name.trim();
              d.users[idx].wa = wa.trim();
              if (avatarUrl) d.users[idx].avatar = avatarUrl;
              d.users[idx].joined = d.users[idx].joined || new Date().toISOString();
            }
            if (d.session) { d.session.name = name.trim(); if (avatarUrl) d.session.avatar = avatarUrl; }
            setDB(d);
            saveDB();
            renderProfile();
            toastU('Profil tersimpan');
            w.remove();
          } else {
            toastU('' + ((res && res.error) || 'Gagal menyimpan profil.'));
            if (btn) { btn.disabled = false; btn.textContent = 'SIMPAN'; }
          }
        }).catch(function () {
          toastU('Gagal terhubung ke server.');
          if (btn) { btn.disabled = false; btn.textContent = 'SIMPAN'; }
        });
      };
      /* foto berubah? upload dulu ke layanan foto → URL */
      var img = w.querySelector('#upEditFoto');
      var file = w.querySelector('#upFotoFile');
      if (img && img.dataset.changed === '1' && file && file.files && file.files[0]) {
        toastU('Mengunggah foto…');
        uploadFoto(file.files[0]).then(finish).catch(function () {
          toastU('Foto gagal diunggah — profil disimpan tanpa ganti foto.');
          finish(null);
        });
      } else {
        finish(null);
      }
      return false; /* modal ditutup manual setelah sukses */
    }, 'SIMPAN');
    // ganti foto: pilih file → upload ke app foto → simpan URL
    setTimeout(function () {
      var img = document.querySelector('.up-modal #upEditFoto');
      var file = document.querySelector('.up-modal #upFotoFile');
      if (img && file) {
        img.onclick = function () { file.click(); };
        file.onchange = function () {
          var f = file.files && file.files[0];
          if (!f) return;
          img.src = URL.createObjectURL(f);
          img.dataset.changed = '1';
        };
      }
    }, 30);
  };

  /* ---------- upload foto ke app foto (Foto ke URL) ---------- */
  /* Foto: dipotong persegi, diperkecil ke 512x512 (tajam/HD), dikompres WebP/JPEG, lalu disimpan di server sendiri */
  function resizeFoto(file) {
    return new Promise(function (res, rej) {
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        try {
          var S = 512, c = document.createElement('canvas'); c.width = c.height = S;
          var x = c.getContext('2d'), m = Math.min(im.naturalWidth, im.naturalHeight), sx = (im.naturalWidth - m) / 2, sy = (im.naturalHeight - m) / 2;
          x.imageSmoothingQuality = 'high'; x.drawImage(im, sx, sy, m, m, 0, 0, S, S);
          var q = .88, d = c.toDataURL('image/webp', q);
          if (d.indexOf('data:image/webp') !== 0) d = c.toDataURL('image/jpeg', q);
          while (d.length > 300000 && q > .4) { q -= .1; d = c.toDataURL(d.indexOf('image/webp') > 0 ? 'image/webp' : 'image/jpeg', q); }
          URL.revokeObjectURL(url); res(d);
        } catch (e) { rej(e); }
      };
      im.onerror = function () { URL.revokeObjectURL(url); rej(new Error('Foto tidak bisa dibaca')); };
      im.src = url;
    });
  }
  function uploadFoto(file) {
    return resizeFoto(file).then(function (data) {
      return fetch('/api/auth/avatar', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ data: data }) })
        .then(function (r) { return r.json().catch(function () { return {}; }); })
        .then(function (j) { if (!j || !j.success || !j.url) throw new Error((j && j.error) || 'Gagal mengunggah'); return j.url; });
    });
  }

  /* ---------- 3) UBAH KATA SANDI (server /api/auth/password) ----------
     Sandi diverifikasi & disimpan di server (PBKDF2). Setelah sukses:
     semua sesi perangkat dihapus → otomatis ke halaman login. */
  window.upStrength = function (v) {
    var sc = 0; if (v.length >= 6) sc++; if (v.length >= 10) sc++; if (/[A-Z]/.test(v) && /[a-z]/.test(v)) sc++; if (/\d/.test(v)) sc++; if (/[^A-Za-z0-9]/.test(v)) sc++;
    var lv = v ? Math.min(4, Math.max(1, sc - (v.length < 6 ? 1 : 0))) : 0, b = document.getElementById('upBar'), t = document.getElementById('upStr');
    if (b) { b.style.width = (lv * 25) + '%'; b.style.background = ['#374151', '#ef4444', '#f59e0b', '#3b82f6', '#22c55e'][lv]; }
    if (t) t.textContent = v ? ['', 'Lemah', 'Cukup', 'Kuat', 'Sangat kuat'][lv] : 'Gunakan huruf, angka, dan simbol.';
  };
  window.upChangePass = function () {
    var eye = '<button type="button" class="up-eye" aria-label="Lihat sandi" onclick="var i=this.previousElementSibling;i.type=i.type===\'password\'?\'text\':\'password\'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></button>';
    var body = '<div class="up-form">'
      + '<label class="up-lbl" for="upOld">Sandi saat ini</label><div class="up-pw"><input class="up-input" id="upOld" type="password" autocomplete="current-password">' + eye + '</div>'
      + '<label class="up-lbl" for="upNew">Sandi baru</label><div class="up-pw"><input class="up-input" id="upNew" type="password" placeholder="Minimal 6 karakter" autocomplete="new-password" oninput="upStrength(this.value)">' + eye + '</div>'
      + '<div class="up-meter"><i id="upBar"></i></div><div class="up-form-note" id="upStr">Gunakan huruf, angka, dan simbol.</div>'
      + '<label class="up-lbl" for="upNew2">Ulangi sandi baru</label><div class="up-pw"><input class="up-input" id="upNew2" type="password" autocomplete="new-password">' + eye + '</div>'
      + '</div>'
      + '<div class="up-form-note">Setelah disimpan, kamu keluar otomatis dari <b>semua perangkat</b> dan masuk lagi dengan sandi baru.</div>';
    smallModal('Ubah Kata Sandi', body, function (w) {
      var old = (w.querySelector('#upOld') || {}).value || '';
      var nw = (w.querySelector('#upNew') || {}).value || '';
      var nw2 = (w.querySelector('#upNew2') || {}).value || '';
      if (!old) { toastU('Sandi saat ini wajib diisi.'); return false; }
      if (nw.length < 6) { toastU('Sandi baru minimal 6 karakter.'); return false; }
      if (nw !== nw2) { toastU('Konfirmasi sandi tidak sama.'); return false; }
      var btn = w.querySelector('#upMOk');
      if (btn) { btn.disabled = true; btn.textContent = 'MENYIMPAN…'; }
      fetch('/api/auth/password', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ old: old, new: nw, confirm: nw2 })
      }).then(function (r) { return r.json().catch(function () { return {}; }); }).then(function (res) {
        if (res && res.success) {
          toastU('Sandi diganti — keluar dari semua perangkat…');
          setTimeout(function () { window.upLogout(true); }, 900);
        } else {
          toastU('' + ((res && res.error) || 'Gagal mengubah sandi.'));
          if (btn) { btn.disabled = false; btn.textContent = 'SIMPAN'; }
        }
      }).catch(function () {
        toastU('Gagal terhubung ke server.');
        if (btn) { btn.disabled = false; btn.textContent = 'SIMPAN'; }
      });
      return false; /* modal ditutup manual setelah sukses */
    }, 'SIMPAN');
  };

  /* ---------- 2b) TOP UP SALDO (balik ke toko → buka modal topup) ---------- */
  window.upGoTopup = function () {
    try { localStorage.setItem('jk_open_topup', '1'); } catch (e) { }
    location.href = '/';
  };

  /* ---------- 4) KELUAR ---------- */
  window.upLogout = function (skipConfirm) {
    var go = function () {
      // hapus sesi lokal + cookie server → kembali ke halaman LOGIN
      try {
        var d = getDB();
        d.session = null;
        setDB(d);
        saveDB();
      } catch (e) { }
      try { ['jka_dv','jka_token','token','jka_admin','jka_username','jka_initialized','user'].forEach(function (k) { localStorage.removeItem(k); }); } catch (e) { }
      var fin = false, once = function () { if (fin) return; fin = true; location.replace('/'); };
      fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }).then(once, once);   /* tunggu cookie terhapus dulu */
      setTimeout(once, 1500);
    };
    if (skipConfirm === true) { go(); }
    else {
      smallModal('Yakin ingin keluar?', '<div class="up-form-note">Sesi akan dihapus dan kamu kembali ke halaman login.</div>', go, 'YA', true, 'TIDAK');
    };
  };

  /* ---------- 5) tambah tombol "👤 Profil" di auth-bar (tanpa ubah tombol lama) ---------- */
  function findAuthBar() {
    // 1) cari link "Keluar" bawaan auth-bar → naik ke elemen bar-nya
    var out = document.querySelector('a[href="/api/auth/logout"]');
    if (out) {
      var b = out.parentElement;
      // naik sampai div level bar (parent yang fixed / bukan <a>)
      while (b && b !== document.body && b.tagName === 'A') b = b.parentElement;
      if (b && b !== document.body) return b;
    }
    // 2) fallback: div dengan style fixed di pojok kanan-bawah (2 format: dengan/tanpa spasi)
    var cands = document.querySelectorAll('div[style*="position:fixed;bottom:12px"], div[style*="position: fixed; bottom: 12px"], div[style*="position:fixed; bottom: 12px"], div[style*="position: fixed;bottom:12px"]');
    for (var i = 0; i < cands.length; i++) {
      if ((cands[i].textContent || '').indexOf('Keluar') >= 0) return cands[i];
    }
    return null;
  }
  function injectProfileLink() {
    if (document.getElementById('upBarLink')) return;
    var bar = findAuthBar();
    if (!bar) return;
    // pastikan user login (bar hanya ada bila login)
    var a = document.createElement('a');
    a.id = 'upBarLink';
    a.href = '/profile';
    a.textContent = '👤 Profil';
    a.style.cssText = 'color:#FFD700;text-decoration:none;font-weight:800;font-size:12px;white-space:nowrap';
    // sisip sebelum link "Keluar" agar urutan: Nama | 👤 Profil | Keluar
    var out = bar.querySelector('a[href="/api/auth/logout"]');
    if (out) bar.insertBefore(a, out); else bar.appendChild(a);
  }
  setInterval(injectProfileLink, 1500);
  setTimeout(injectProfileLink, 400);

  /* ---------- init ---------- */
  function boot() {
    // di halaman toko (index.html): bendera topup → buka modal topup bawaan
    if (document.body && document.getElementById('upBody')) {
      renderProfile();
      window.addEventListener('resize', debounce(renderProfile, 250));
      return;
    }
    // di index.html: jika pengguna menekan TOPUP dari profil → buka topup bawaan
    try {
      if (localStorage.getItem('jk_open_topup') === '1') {
        localStorage.removeItem('jk_open_topup');
        setTimeout(function () {
          try { openTopup(); } catch (e) {
            try {
              var b = document.querySelector('#userBtn');
              if (b) b.click();
            } catch (e2) { }
          }
        }, 700);
      }
    } catch (e) { }
  }
  function debounce(fn, ms) {
    var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
