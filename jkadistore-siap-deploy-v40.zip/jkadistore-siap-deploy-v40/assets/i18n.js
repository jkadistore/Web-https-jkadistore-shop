/* Multi bahasa: Indonesia (asli), English, Bahasa Melayu, 简体中文, Filipino.
   Teks asli (Indonesia) tetap di HTML; teks diganti langsung di browser saat bahasa dipilih. */
(function () {
  'use strict';
  var LANGS = [
    { c: 'id', n: 'Indonesia', s: 'ID', loc: 'id-ID', h: 'id' },
    { c: 'en', n: 'English', s: 'EN', loc: 'en-GB', h: 'en' },
    { c: 'ms', n: 'Bahasa Melayu', s: 'MS', loc: 'ms-MY', h: 'ms' },
    { c: 'zh', n: '简体中文', s: '中文', loc: 'zh-CN', h: 'zh-CN' },
    { c: 'tl', n: 'Filipino', s: 'FIL', loc: 'fil-PH', h: 'fil' }
  ];
  var IDX = { en: 0, ms: 1, zh: 2, tl: 3 };
  var D = window.JK_I18N_DICT || {};
  var EX = {
    'Stok habis': ['Out of stock', 'Stok habis', '缺货', 'Walang stock'],
    'diterapkan — hemat': ['applied — you save', 'digunakan — jimat', '已应用——节省', 'nailapat — matitipid mo'],
    'Hemat': ['Saved', 'Jimat', '节省', 'Natipid'],
    'Hemat sampai': ['Save up to', 'Jimat sehingga', '最高节省', 'Makatipid ng hanggang'],
    'untuk produk pilihan. Berganti setiap hari.': ['on selected products. Changes daily.', 'untuk produk pilihan. Berubah setiap hari.', '适用于精选商品，每日更换。', 'sa piling produkto. Nagbabago araw-araw.'],
    'di seluruh domain': ['across all domains', 'di semua domain', '适用于所有域名', 'sa lahat ng domain'],
    'AKUN': ['ACCOUNT', 'AKAUN', '账号', 'ACCOUNT'],
    'Harga Final': ['Final Price', 'Harga Akhir', '最终价格', 'Pinal na Presyo'],
    'Semua kategori': ['All categories', 'Semua kategori', '全部分类', 'Lahat ng kategorya']
  };
  function pick(a, c) { return a ? a[IDX[c]] : null; }
  function kfmt(n, c) { return c === 'id' ? n : String(n).replace(/rb\+?/i, function (m) { return 'k' + (m.slice(-1) === '+' ? '+' : ''); }); }
  var PAT = [
    [/^(\d[\d.,]*(?:rb)?\+?) terjual$/, ['$1 sold', '$1 terjual', '已售 $1', '$1 nabenta']],
    [/^Terjual (.+)$/, ['Sold $1', 'Terjual $1', '已售 $1', 'Nabenta: $1']],
    [/^Stok tersedia · (.+) terjual$/, ['In stock · $1 sold', 'Stok tersedia · $1 terjual', '有库存 · 已售 $1', 'May stock · $1 nabenta']],
    [/^(\d+) paket tersedia — semua nominal$/, ['$1 packages available — all amounts', '$1 pakej tersedia — semua nilai', '共 $1 个套餐——所有面额', '$1 package available — lahat ng halaga']],
    [/^(\d+) paket tersedia — kecil → besar$/, ['$1 packages available — small → large', '$1 pakej tersedia — kecil → besar', '共 $1 个套餐——由小到大', '$1 package available — maliit → malaki']],
    [/^(\d+) paket — kecil → besar$/, ['$1 packages — small → large', '$1 pakej — kecil → besar', '$1 个套餐——由小到大', '$1 package — maliit → malaki']],
    [/^(\d+) paket$/, ['$1 packages', '$1 pakej', '$1 个套餐', '$1 package']],
    [/^(\d+) Kanal$/, ['$1 Channels', '$1 Saluran', '$1 个渠道', '$1 Channel']],
    [/^(\d+) produk$/, ['$1 products', '$1 produk', '$1 件商品', '$1 produkto']],
    [/^Sejak (.+)$/, ['Since $1', 'Sejak $1', '自 $1 起', 'Mula $1']],
    [/^(\d+) selesai$/, ['$1 completed', '$1 selesai', '已完成 $1 笔', '$1 tapos na']],
    [/^(Rp [\d.,]+) belanja$/, ['$1 spent', '$1 dibelanjakan', '已消费 $1', '$1 ang nagastos']],
    [/^Saldo (.+)$/, ['$1 balance', 'Baki $1', '$1 余额', '$1 balance']],
    [/^Pulsa (.+)$/, ['$1 airtime', 'Kredit $1', '$1 话费', '$1 load']],
    [/^Mulai (Rp [\d.,]+)$/, ['From $1', 'Mulai $1', '起价 $1', 'Simula sa $1']],
    [/^Min\. (Rp [\d.,]+)$/, ['Min. $1', 'Min. $1', '最低 $1', 'Min. $1']],
    [/^Tampilkan lebih banyak \((\d+) lagi\)$/, ['Show more ($1 more)', 'Tunjukkan lagi ($1 lagi)', '显示更多（还有 $1 项）', 'Magpakita pa ($1 pa)']],
    [/^Voucher (\S+) diterapkan — hemat (Rp [\d.,]+)$/, ['Voucher $1 applied — you save $2', 'Baucar $1 digunakan — jimat $2', '优惠码 $1 已应用——节省 $2', 'Nailapat ang voucher $1 — matitipid mo $2']],
    [/^Diskon (\S+) diterapkan — harga berubah otomatis$/, ['Discount $1 applied — price updated automatically', 'Diskaun $1 digunakan — harga berubah secara automatik', '折扣 $1 已应用——价格自动更新', 'Nailapat ang diskwento $1 — awtomatikong nagbago ang presyo']],
    [/^Kode (\S+) berlaku untuk transaksi minimal (Rp [\d.,]+)$/, ['Code $1 requires a minimum purchase of $2', 'Kod $1 sah untuk transaksi minimum $2', '优惠码 $1 需满 $2 方可使用', 'Ang code na $1 ay para sa minimum na $2']],
    [/^Nickname ditemukan: (.+)$/, ['Nickname found: $1', 'Nama panggilan ditemui: $1', '已找到昵称：$1', 'Nahanap ang nickname: $1']],
    [/^Invoice: (.+)$/, ['Invoice: $1', 'Invois: $1', '发票：$1', 'Invoice: $1']],
    [/^Beli (\d+)x (.+) seharga (Rp [\d.,]+)\? Konfirmasi pembelian Anda\.$/, ['Buy $1x $2 for $3? Please confirm your purchase.', 'Beli $1x $2 pada harga $3? Sila sahkan pembelian anda.', '以 $3 购买 $1 件 $2？请确认购买。', 'Bilhin ang $1x $2 sa halagang $3? Pakikumpirma ang pagbili mo.']]
  ];
  var MON = { Januari: 0, Februari: 1, Maret: 2, April: 3, Mei: 4, Juni: 5, Juli: 6, Agustus: 7, September: 8, Oktober: 9, November: 10, Desember: 11 };
  var DATE_RE = /^(?:Senin|Selasa|Rabu|Kamis|Jumat|Sabtu|Minggu), (\d{1,2}) (Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember) (\d{4})$/;
  var EMO = /[‼⁉⃣™ℹ↔-↪⌚-⏺Ⓜ▪-◾☀-➿⤴⤵⬀-⯿〰〽㊗㊙️\u{1F000}-\u{1FAFF}\u{200D}]/gu;

  var lang = 'id', busy = false;
  var TN = new WeakMap(), AN = new WeakMap();
  var SKIP = /^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|CODE|PRE|INPUT|SELECT|OPTION)$/;
  var ATTRS = ['placeholder', 'title', 'aria-label'];
  var cache = {};

  function tr(raw, c) {
    if (c === 'id') return raw;
    var key = raw.replace(/\s+/g, ' ').trim();
    if (!key) return raw;
    var ck = c + '|' + key; if (cache[ck] !== undefined) return cache[ck] === null ? raw : cache[ck];
    var k2 = key.replace(EMO, '').replace(/\s+/g, ' ').trim();
    var out = null, a = D[key] || D[k2] || EX[key] || EX[k2];
    if (a) out = pick(a, c);
    if (!out) {
      var m = DATE_RE.exec(k2);
      if (m) { try { out = new Intl.DateTimeFormat(LANGS.filter(function (l) { return l.c === c; })[0].loc, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(+m[3], MON[m[2]], +m[1])); } catch (e) {} }
    }
    if (!out) for (var i = 0; i < PAT.length; i++) {
      var mm = PAT[i][0].exec(k2);
      if (mm) { out = pick(PAT[i][1], c).replace(/\$(\d)/g, function (_, n) { return n === '1' && i < 3 ? kfmt(mm[1], c) : (mm[+n] || ''); }); break; }
    }
    if (out) {
      var lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0];
      out = lead + out + trail;
    }
    cache[ck] = out === null ? null : out;
    return out === null ? raw : out;
  }

  function doText(n) {
    var p = n.parentNode; if (!p || p.nodeType !== 1 || SKIP.test(p.tagName)) return;
    if (p.closest && p.closest('.notranslate,[translate="no"],[data-i18n-skip]')) return;
    var cur = n.nodeValue, rec = TN.get(n);
    if (rec && cur === rec.t) { /* masih hasil terjemahan kita */ }
    else { rec = { o: cur, t: cur }; TN.set(n, rec); }
    var out = tr(rec.o, lang);
    if (out !== cur) { n.nodeValue = out; }
    rec.t = out;
  }
  function doAttrs(el) {
    if (el.closest && el.closest('.notranslate,[translate="no"],[data-i18n-skip]')) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i], v = el.getAttribute(a); if (v == null || !v.trim()) continue;
      var m = AN.get(el); if (!m) { m = {}; AN.set(el, m); }
      var rec = m[a];
      if (!rec || v !== rec.t) { rec = m[a] = { o: v, t: v }; }
      var out = tr(rec.o, lang);
      if (out !== v) el.setAttribute(a, out);
      rec.t = out;
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1) return;
    if (SKIP.test(root.tagName) && root.tagName !== 'INPUT' && root.tagName !== 'TEXTAREA') return;
    var tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null), n;
    if (root.nodeType === 1) doAttrs(root);
    while ((n = tw.nextNode())) { if (n.nodeType === 3) doText(n); else doAttrs(n); }
  }
  var origTitle = document.title;
  function applyAll() {
    busy = true;
    try { walk(document.body); document.title = tr(origTitle, lang); } finally { busy = false; }
    if (mo) mo.takeRecords();
  }
  var mo = null;
  function observe() {
    mo = new MutationObserver(function (list) {
      if (busy) return;
      busy = true;
      try {
        list.forEach(function (r) {
          if (r.type === 'childList') r.addedNodes.forEach(function (n) { walk(n); });
          else if (r.type === 'characterData') doText(r.target);
          else if (r.type === 'attributes') doAttrs(r.target);
        });
      } finally { busy = false; }
      mo.takeRecords();
    });
    mo.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  function meta(c) { return LANGS.filter(function (l) { return l.c === c; })[0] || LANGS[0]; }
  function setLang(c, silent) {
    if (!meta(c) || (c === lang && !silent)) return;
    lang = c;
    try { localStorage.setItem('jk_lang', c); } catch (e) {}
    document.documentElement.lang = meta(c).h;
    document.documentElement.dir = 'ltr';
    applyAll(); mark();
    try { document.dispatchEvent(new CustomEvent('jk:lang', { detail: c })); } catch (e) {}
  }
  function detect() {
    try { var q = new URLSearchParams(location.search).get('lang'); if (q && meta(q).c === q) return q; } catch (e) {}
    try { var s = localStorage.getItem('jk_lang'); if (s && meta(s).c === s) return s; } catch (e) {}
    var nl = (navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'id']);
    for (var i = 0; i < nl.length; i++) {
      var x = String(nl[i]).toLowerCase();
      if (/^id\b|^in\b/.test(x)) return 'id';
      if (/^ms\b/.test(x)) return 'ms';
      if (/^zh\b/.test(x)) return 'zh';
      if (/^(fil|tl)\b/.test(x)) return 'tl';
      if (/^en\b/.test(x)) return 'en';
    }
    return 'en';
  }

  /* ---- tombol pilih bahasa ---- */
  var CSS = '.jkl{position:relative;display:inline-flex}.jkl-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-width:40px;height:40px;padding:0 10px;border-radius:12px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.06);color:#fff;font:700 12px/1 system-ui,sans-serif;letter-spacing:.04em;cursor:pointer}'
    + '.jkl-menu{display:none;position:absolute;right:0;top:calc(100% + 8px);min-width:190px;background:#0d1020;border:1px solid #232b4a;border-radius:14px;padding:6px;box-shadow:0 14px 40px rgba(0,0,0,.55);z-index:2147483000}.jkl-menu.on{display:block}'
    + '.jkl-menu button{display:flex;width:100%;justify-content:space-between;align-items:center;gap:12px;background:transparent;border:0;border-radius:10px;padding:10px 12px;color:#f2f4fb;font:inherit;font-size:14px;cursor:pointer;text-align:left}.jkl-menu button i{font-style:normal;font-size:11px;color:#8d94ac}'
    + '.jkl-menu button:hover{background:rgba(74,124,245,.14)}.jkl-menu button[aria-checked="true"]{background:rgba(47,99,224,.22);font-weight:700}.jkl-float{position:fixed;top:12px;right:12px;z-index:2147482999}';
  function injectCss() { if (document.getElementById('jklCss')) return; var s = document.createElement('style'); s.id = 'jklCss'; s.textContent = CSS; (document.head || document.documentElement).appendChild(s); }
  var wrap, btn, menu, floatOk = false;
  function mark() {
    if (!btn) return;
    btn.querySelector('.jkl-code').textContent = meta(lang).s;
    menu.querySelectorAll('button').forEach(function (b) { b.setAttribute('aria-checked', b.getAttribute('data-c') === lang ? 'true' : 'false'); });
  }
  function build() {
    if (document.getElementById('jkLang')) return true;
    injectCss();
    var host = document.querySelector('.kActions') || document.querySelector('.topbar .nav'), floating = false;
    if (!host) { if (!floatOk) return false; host = document.body; floating = true; }
    wrap = document.createElement('div'); wrap.id = 'jkLang'; wrap.className = 'jkl notranslate'; wrap.setAttribute('translate', 'no');
    btn = document.createElement('button'); btn.type = 'button'; btn.className = 'kIconBtn jkl-btn'; btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Language');
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3z"/></svg><span class="jkl-code"></span>';
    menu = document.createElement('div'); menu.className = 'jkl-menu'; menu.setAttribute('role', 'listbox');
    LANGS.forEach(function (l) {
      var b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'option'); b.setAttribute('data-c', l.c); b.setAttribute('lang', l.h);
      b.innerHTML = '<span>' + l.n + '</span><i>' + l.s + '</i>';
      b.addEventListener('click', function () { setLang(l.c); close(); });
      menu.appendChild(b);
    });
    wrap.appendChild(btn); wrap.appendChild(menu);
    if (floating) wrap.classList.add('jkl-float');
    host.insertBefore(wrap, host.firstChild);
    function open() { menu.classList.add('on'); btn.setAttribute('aria-expanded', 'true'); }
    function close() { menu.classList.remove('on'); btn.setAttribute('aria-expanded', 'false'); }
    btn.addEventListener('click', function (e) { e.stopPropagation(); menu.classList.contains('on') ? close() : open(); });
    document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    mark(); return true;
  }

  function start() {
    lang = detect();
    document.documentElement.lang = meta(lang).h;
    var tries = 0, iv = setInterval(function () { if (++tries > 8) floatOk = true; if (build() || tries > 40) clearInterval(iv); }, 250);
    build();
    observe();
    if (lang !== 'id') applyAll();
    mark();
    /* konten dari skrip lain (kartu produk, data server) ikut diterjemahkan lewat observer; sapu ulang sebentar */
    var k = 0, iv2 = setInterval(function () { if (lang !== 'id') applyAll(); if (++k > 6) clearInterval(iv2); }, 800);
  }
  window.JK_I18N = { set: setLang, get: function () { return lang; }, t: function (s) { return tr(s, lang); }, langs: LANGS };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
