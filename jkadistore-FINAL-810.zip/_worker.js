/* JK ADISTORE — Pages Functions bridge
   Meneruskan route dinamis (/api/*, /keys/*, dan route tak dikenal)
   ke deployment asli 25bd5ade yang memiliki binding D1 aktif. */
const ORIGIN = 'https://25bd5ade.jkadistore.pages.dev';

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/keys/')) {
      const target = ORIGIN + url.pathname + url.search;
      const h = new Headers(request.headers);
      h.set('Host', new URL(ORIGIN).hostname);
      const init = {
        method: request.method,
        headers: h,
        body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
        redirect: 'manual'
      };
      return fetch(new Request(target, init));
    }
    return env.ASSETS.fetch(request);
  }
};
